/* global React */
// =============================================================================
// Icons — hand-drawn 16×16 line icons (1.6px stroke) for the editor.
// Every icon is a function returning <svg>. All use currentColor.
// =============================================================================

const S = { viewBox: '0 0 16 16', width: 16, height: 16, fill: 'none', stroke: 'currentColor', strokeWidth: 1.4, strokeLinecap: 'round', strokeLinejoin: 'round' };

const Icon = {
  // File / app
  open:     () => (<svg {...S}><path d="M2 4.5a1 1 0 0 1 1-1h3l1.3 1.5H13a1 1 0 0 1 1 1V12a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4.5Z"/></svg>),
  save:     () => (<svg {...S}><path d="M3 3h8.5L13 4.5V13a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V3Z"/><path d="M5 3v3h5V3M5 10h6"/></svg>),
  saveAs:   () => (<svg {...S}><path d="M3 3h8L13 4.5V12a1 1 0 0 1-1 1H7"/><path d="M5 3v3h5V3"/><path d="m4 14 1.5-3 4.5-4.5 1.5 1.5L7 12.5 4 14Z"/></svg>),
  print:    () => (<svg {...S}><rect x="4" y="2.5" width="8" height="4" rx="0.5"/><rect x="2.5" y="6.5" width="11" height="5" rx="1"/><rect x="4" y="10" width="8" height="3.5" rx="0.5"/><circle cx="11.5" cy="8.5" r="0.4" fill="currentColor" stroke="none"/></svg>),
  optimize: () => (<svg {...S}><path d="M3 3h7l3 3v7a1 1 0 0 1-1 1H3Z"/><path d="M5.5 8.5 8 11l3.5-4"/></svg>),

  // Modes
  hand:     () => (<svg {...S}><path d="M5 9V4a1 1 0 0 1 2 0v4M7 8V3a1 1 0 0 1 2 0v5M9 8V4a1 1 0 0 1 2 0v5M11 9V6a1 1 0 0 1 2 0v4c0 2-1.5 3.5-3.5 3.5H8c-1.5 0-2.5-.8-3-2L3.2 8.8A.9.9 0 0 1 4.5 7.6L5 9Z"/></svg>),
  editText: () => (<svg {...S}><path d="M2 13.5 3 10l7-7 2.5 2.5L5.5 13l-3.5.5Z"/><path d="m9 4 2.5 2.5"/></svg>),
  addText:  () => (<svg {...S}><path d="M3 4h8M7 4v9M5 13h4"/><circle cx="12.5" cy="12.5" r="2"/><path d="M12.5 11.5v2M11.5 12.5h2"/></svg>),
  rect:     () => (<svg {...S}><rect x="2.5" y="3.5" width="11" height="9" rx="1"/></svg>),
  highlight:() => (<svg {...S}><path d="M3 12.5 2.5 14M10.5 3.5l-6 6L6 11l6-6-1.5-1.5Z"/><path d="M4.5 9.5 7 12"/></svg>),
  annotate: () => (<svg {...S}><path d="M2.5 4a1 1 0 0 1 1-1h9a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1H7l-3 2.5V11H3.5a1 1 0 0 1-1-1V4Z"/></svg>),
  objects:  () => (<svg {...S}><rect x="2" y="2" width="7" height="7" rx="0.5"/><rect x="7" y="7" width="7" height="7" rx="0.5" fill="currentColor" fillOpacity="0.15"/></svg>),
  insertImage: () => (<svg {...S}><rect x="2.5" y="2.5" width="11" height="11" rx="1"/><circle cx="6" cy="6" r="1"/><path d="m3 12 3-3 3 3 2-2 2 2"/></svg>),

  // Page ops
  deletePage:()=> (<svg {...S}><path d="M3 3h8v11H3Z"/><path d="M5 6v5M8 6v5"/><path d="M12.5 4.5h-10M6 3V2h4v1"/></svg>),
  rotatePage:()=> (<svg {...S}><path d="M13 8A5 5 0 1 1 8 3V5M8 1.5 10 3 8 4.5"/></svg>),
  exportPage:()=> (<svg {...S}><path d="M3 3h6l4 4v6a1 1 0 0 1-1 1H3Z"/><path d="M9 3v4h4"/><path d="M6 11h4M8 9v4"/></svg>),
  insertBlank:()=>(<svg {...S}><path d="M3 3h6l4 4v6a1 1 0 0 1-1 1H3Z"/><path d="M9 3v4h4"/><path d="M8 9v3M6.5 10.5h3"/></svg>),
  insertFromFile:()=>(<svg {...S}><path d="M3 3h6l4 4v6a1 1 0 0 1-1 1H3Z"/><path d="M9 3v4h4"/><path d="m5.5 11.5 2-2 2 2M7.5 9.5V13"/></svg>),
  merge:    () => (<svg {...S}><rect x="2" y="2.5" width="6" height="6" rx="0.5"/><rect x="8" y="7.5" width="6" height="6" rx="0.5"/><path d="M6 8v.5a2 2 0 0 0 2 2H8"/></svg>),

  // Convert
  ocr:      () => (<svg {...S}><rect x="2.5" y="2.5" width="11" height="11" rx="1"/><path d="M5 5h1M10 5h1M5 10h1M10 10h1"/><path d="M5 11V5h2M8 5h3v2M11 8v3H8"/></svg>),

  // Common
  undo:     () => (<svg {...S}><path d="M3.5 7.5h7a3 3 0 0 1 0 6H7"/><path d="m6 5-2.5 2.5L6 10"/></svg>),
  redo:     () => (<svg {...S}><path d="M12.5 7.5h-7a3 3 0 0 0 0 6H9"/><path d="m10 5 2.5 2.5L10 10"/></svg>),
  fullscreen:()=>(<svg {...S}><path d="M2.5 6V2.5H6M14 6V2.5H10.5M2.5 10v3.5H6M14 10v3.5H10.5"/></svg>),
  exitFull: () => (<svg {...S}><path d="M6 2.5V6H2.5M10 2.5V6h3.5M6 13.5V10H2.5M10 13.5V10h3.5"/></svg>),
  snapshot: () => (<svg {...S}><path d="M2.5 5h2.5l1-1.5h4L11 5h2.5a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1H2.5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1Z"/><circle cx="8" cy="9" r="2.2"/></svg>),

  // Sidebar tabs
  thumbs:   () => (<svg {...S}><rect x="2.5" y="2.5" width="5" height="5" rx="0.5"/><rect x="8.5" y="2.5" width="5" height="5" rx="0.5"/><rect x="2.5" y="8.5" width="5" height="5" rx="0.5"/><rect x="8.5" y="8.5" width="5" height="5" rx="0.5"/></svg>),
  search:   () => (<svg {...S}><circle cx="7" cy="7" r="4"/><path d="m10 10 3.5 3.5"/></svg>),
  comments: () => (<svg {...S}><path d="M2.5 4a1 1 0 0 1 1-1h9a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1H7l-3 2.5V11H3.5a1 1 0 0 1-1-1V4Z"/><path d="M5 6.5h6M5 8.5h4"/></svg>),
  watermark:() => (<svg {...S}><path d="M8 2c2 3 3.5 5 3.5 7a3.5 3.5 0 1 1-7 0C4.5 7 6 5 8 2Z"/></svg>),
  bookmark: () => (<svg {...S}><path d="M4 2.5h8v11l-4-2.5-4 2.5Z"/></svg>),
  layers:   () => (<svg {...S}><path d="m8 2 6 3-6 3-6-3 6-3ZM2 8l6 3 6-3M2 11l6 3 6-3"/></svg>),

  // Inspector / misc
  settings: () => (<svg {...S}><circle cx="8" cy="8" r="2"/><path d="M8 1.5v2M8 12.5v2M1.5 8h2M12.5 8h2M3.3 3.3l1.4 1.4M11.3 11.3l1.4 1.4M3.3 12.7l1.4-1.4M11.3 4.7l1.4-1.4"/></svg>),
  chevronDown:()=>(<svg {...S}><path d="m4 6 4 4 4-4"/></svg>),
  chevronLeft:()=>(<svg {...S}><path d="m10 4-4 4 4 4"/></svg>),
  chevronRight:()=>(<svg {...S}><path d="m6 4 4 4-4 4"/></svg>),
  plus:     () => (<svg {...S}><path d="M8 3v10M3 8h10"/></svg>),
  minus:    () => (<svg {...S}><path d="M3 8h10"/></svg>),
  x:        () => (<svg {...S}><path d="m4 4 8 8M12 4l-8 8"/></svg>),
  check:    () => (<svg {...S}><path d="m3 8 3.5 3.5L13 5"/></svg>),
  kbd:      () => (<svg {...S}><rect x="1.5" y="4.5" width="13" height="7" rx="1"/><path d="M4 7h1M7 7h1M10 7h1M4 9.5h7"/></svg>),
  eye:      () => (<svg {...S}><path d="M1.5 8S4 4 8 4s6.5 4 6.5 4S12 12 8 12 1.5 8 1.5 8Z"/><circle cx="8" cy="8" r="1.8"/></svg>),
  eyeOff:   () => (<svg {...S}><path d="M3 3.5 12.5 13M3.5 5.5C2.2 6.7 1.5 8 1.5 8S4 12 8 12c1 0 1.9-.25 2.7-.6M6.5 5a7 7 0 0 1 1.5-.2c4 0 6.5 3.2 6.5 3.2s-.7 1.1-2 2.3"/></svg>),
  pages:    () => (<svg {...S}><rect x="3.5" y="2.5" width="8" height="10" rx="0.5"/><path d="M5.5 5h4M5.5 7h4M5.5 9h3"/></svg>),
  zoomIn:   () => (<svg {...S}><circle cx="7" cy="7" r="4"/><path d="m10 10 3.5 3.5M5 7h4M7 5v4"/></svg>),
  zoomOut:  () => (<svg {...S}><circle cx="7" cy="7" r="4"/><path d="m10 10 3.5 3.5M5 7h4"/></svg>),
  fitView:  () => (<svg {...S}><path d="M2.5 5V2.5H5M11 2.5h2.5V5M2.5 11v2.5H5M11 13.5h2.5V11"/><rect x="5.5" y="5.5" width="5" height="5" rx="0.5"/></svg>),
  grid:     () => (<svg {...S}><rect x="2.5" y="2.5" width="11" height="11" rx="0.5"/><path d="M2.5 8h11M8 2.5v11"/></svg>),
  palette:  () => (<svg {...S}><path d="M8 2a6 6 0 1 0 1.5 11.8c.8-.2 1-1.1.4-1.7-.5-.6-.3-1.6.6-1.8l1-.2A3 3 0 0 0 14 7a6 6 0 0 0-6-5Z"/><circle cx="5" cy="7" r=".6" fill="currentColor" stroke="none"/><circle cx="6.5" cy="4.5" r=".6" fill="currentColor" stroke="none"/><circle cx="10" cy="4.5" r=".6" fill="currentColor" stroke="none"/></svg>),
  moreH:    () => (<svg {...S}><circle cx="4" cy="8" r=".8" fill="currentColor" stroke="none"/><circle cx="8" cy="8" r=".8" fill="currentColor" stroke="none"/><circle cx="12" cy="8" r=".8" fill="currentColor" stroke="none"/></svg>),
  moreV:    () => (<svg {...S}><circle cx="8" cy="4" r=".8" fill="currentColor" stroke="none"/><circle cx="8" cy="8" r=".8" fill="currentColor" stroke="none"/><circle cx="8" cy="12" r=".8" fill="currentColor" stroke="none"/></svg>),
  sidebar:  () => (<svg {...S}><rect x="2" y="3" width="12" height="10" rx="1"/><path d="M6 3v10"/></svg>),
  sidebarR: () => (<svg {...S}><rect x="2" y="3" width="12" height="10" rx="1"/><path d="M10 3v10"/></svg>),
  cmd:      () => (<svg {...S}><rect x="1.5" y="1.5" width="13" height="13" rx="2"/><path d="M5.5 5.5h5v5h-5z"/></svg>),
  sun:      () => (<svg {...S}><circle cx="8" cy="8" r="2.5"/><path d="M8 1.5v2M8 12.5v2M1.5 8h2M12.5 8h2M3.5 3.5l1.4 1.4M11.1 11.1l1.4 1.4M3.5 12.5l1.4-1.4M11.1 4.9l1.4-1.4"/></svg>),
  moon:     () => (<svg {...S}><path d="M13 9.5A5 5 0 1 1 6.5 3a4 4 0 0 0 6.5 6.5Z"/></svg>),
  brush:    () => (<svg {...S}><path d="M11 2.5 13.5 5 7 11.5H4V9L10.5 2.5Z"/><path d="M4 11 2.5 13.5 5 12"/></svg>),

  // Window controls (win11)
  winMin:   () => (<svg viewBox="0 0 10 10" width="10" height="10" fill="none" stroke="currentColor" strokeWidth="1"><path d="M1 5h8"/></svg>),
  winMax:   () => (<svg viewBox="0 0 10 10" width="10" height="10" fill="none" stroke="currentColor" strokeWidth="1"><rect x="1.5" y="1.5" width="7" height="7"/></svg>),
  winX:     () => (<svg viewBox="0 0 10 10" width="10" height="10" fill="none" stroke="currentColor" strokeWidth="1"><path d="m1.5 1.5 7 7M8.5 1.5l-7 7"/></svg>),
};

// =============================================================================
// PNG icon overrides — colorful illustration set used in the ribbon.
// Render as <img> at 100% of parent so callers control sizing via container.
// =============================================================================
const ICON_BASE = 'assets/icons/';
function PNG(file) {
  return () => (
    <img src={ICON_BASE + file} alt="" draggable={false}
      style={{
        width: '100%', height: '100%', objectFit: 'contain',
        display: 'block', userSelect: 'none', pointerEvents: 'none',
      }}/>
  );
}

Object.assign(Icon, {
  // 檔案
  open:           PNG('01-open.png'),
  print:          PNG('02-print.png'),
  save:           PNG('03-save.png'),
  saveAs:         PNG('04-save-as.png'),
  optimize:       PNG('05-optimize.png'),
  // 常用
  hand:           PNG('06-browse.png'),
  objects:        PNG('07-objects.png'),
  undo:           PNG('08-undo.png'),
  redo:           PNG('09-redo.png'),
  fullscreen:     PNG('10-fullscreen.png'),
  thumbs:         PNG('11-thumbs.png'),
  search:         PNG('12-search.png'),
  snapshot:       PNG('13-snapshot.png'),
  // 編輯
  editText:       PNG('14-edit-text.png'),
  addText:        PNG('15-add-text.png'),
  rect:           PNG('16-rect.png'),
  highlight:      PNG('17-highlight.png'),
  annotate:       PNG('18-add-annotation.png'),
  insertImage:    PNG('19-insert-image.png'),
  pasteImage:     PNG('20-paste-image.png'),
  comments:       PNG('21-comments.png'),
  watermark:      PNG('22-watermark-add.png'),
  layers:         PNG('23-watermark-list.png'),
  eye:            PNG('24-toggle-annotations.png'),
  // 頁面
  deletePage:     PNG('25-delete-page.png'),
  rotatePage:     PNG('26-rotate-page.png'),
  exportPage:     PNG('27-export-page.png'),
  insertBlank:    PNG('28-insert-blank.png'),
  insertFromFile: PNG('29-insert-from-file.png'),
  merge:          PNG('30-merge.png'),
  // 轉換
  ocr:            PNG('31-ocr.png'),
});

window.Icon = Icon;
