/* global React */
// Shared hooks for the prototype.
function useLocalState(key, initial) {
  const [v, setV] = React.useState(() => {
    try { const raw = localStorage.getItem(key); return raw !== null ? JSON.parse(raw) : initial; } catch { return initial; }
  });
  React.useEffect(() => { try { localStorage.setItem(key, JSON.stringify(v)); } catch {} }, [key, v]);
  return [v, setV];
}

// Shared doc state: mode, selection, editing, page, zoom, sidebars, etc.
function useEditorState(prefix = 'v1') {
  const [mode, setMode] = useLocalState(`${prefix}:mode`, 'browse');
  const [selectedBlockId, setSelectedBlockId] = React.useState(null);
  const [hoveredBlockId, setHoveredBlockId] = React.useState(null);
  const [editingBlockId, setEditingBlockId] = React.useState(null);
  const [editingValue, setEditingValue] = React.useState('');
  const [filledValues, setFilledValues] = useLocalState(`${prefix}:values`, {});
  const [leftTab, setLeftTab] = useLocalState(`${prefix}:leftTab`, 'thumbs');
  const [leftOpen, setLeftOpen] = useLocalState(`${prefix}:leftOpen`, true);
  const [rightOpen, setRightOpen] = useLocalState(`${prefix}:rightOpen`, true);
  const [ribbonTab, setRibbonTab] = useLocalState(`${prefix}:ribbon`, 'common');
  const [zoom, setZoom] = useLocalState(`${prefix}:zoom`, 100);
  const [page, setPage] = useLocalState(`${prefix}:page`, 1);
  const [docTab, setDocTab] = useLocalState(`${prefix}:docTab`, 0);
  const [showBlockOutlines, setShowBlockOutlines] = React.useState(false);
  const [highlights, setHighlights] = useLocalState(`${prefix}:highlights`, [
    { x: 164, y: 293, w: 220, h: 20, color: '#ffe27a' },
  ]);
  const [annotations, setAnnotations] = useLocalState(`${prefix}:annos`, [
    { x: 395, y: 415, text: '請確認用途欄位是否與銀行核貸表一致。', author: '陳承辦員' },
  ]);
  const [watermark, setWatermark] = useLocalState(`${prefix}:wm`, null);
  const [targetMode, setTargetMode] = useLocalState(`${prefix}:tgt`, 'paragraph');

  React.useEffect(() => { if (mode === 'edit_text') setShowBlockOutlines(true); else setShowBlockOutlines(false); }, [mode]);

  const onBlockClick = React.useCallback((id) => {
    if (mode === 'edit_text' || mode === 'add_text') {
      setEditingBlockId(id);
      setEditingValue(filledValues[id] ?? '');
      setSelectedBlockId(id);
    } else if (mode === 'highlight') {
      // Simulate: add a highlight on that block — pretend coords
      setHighlights((h) => [...h, { x: 200, y: 350 + (h.length*24), w: 150, h: 18 }]);
      setSelectedBlockId(id);
    } else if (mode === 'add_annotation') {
      setAnnotations((a) => [...a, { x: 380, y: 200 + (a.length*60), text: '新註解…', author: '我' }]);
      setSelectedBlockId(id);
    } else {
      setSelectedBlockId(id);
    }
  }, [mode, filledValues, setHighlights, setAnnotations]);

  const commitEdit = React.useCallback(() => {
    if (!editingBlockId) return;
    setFilledValues((v) => ({ ...v, [editingBlockId]: editingValue }));
    setEditingBlockId(null);
    setEditingValue('');
  }, [editingBlockId, editingValue, setFilledValues]);

  return {
    mode, setMode, selectedBlockId, setSelectedBlockId,
    hoveredBlockId, setHoveredBlockId,
    editingBlockId, editingValue, setEditingValue,
    onBlockClick, commitEdit,
    filledValues, setFilledValues,
    leftTab, setLeftTab, leftOpen, setLeftOpen,
    rightOpen, setRightOpen,
    ribbonTab, setRibbonTab,
    zoom, setZoom, page, setPage, docTab, setDocTab,
    showBlockOutlines, highlights, annotations, watermark, setWatermark,
    targetMode, setTargetMode,
  };
}

window.useEditorState = useEditorState;
window.useLocalState = useLocalState;
