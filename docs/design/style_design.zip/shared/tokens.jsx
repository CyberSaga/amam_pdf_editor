/* global React */
// =============================================================================
// Design tokens — a tight, quiet, dense desktop aesthetic.
// Two themes (light + dark), single accent ("ink" = brand blue), dense spacing.
// Every component reads from these; no magic colors in variation files.
// =============================================================================

// -----------------------------------------------------------------------------
// PALETTES — six soft pastel lavender/purple variations
// Each one defines just the chromatic keys; THEMES.light fills the rest.
// -----------------------------------------------------------------------------
const PALETTES = {
  lavender_mist: {
    name: '薰衣草霧',
    en:   'Lavender Mist',
    bg:'#dcd6e8', surface:'#f6f3fb', sunken:'#cfc7df', elev:'#fcfaff',
    line:'#c6bfd6', lineStrong:'#a89dc4', lineSoft:'#d8d1e4',
    accent:'#8666c8', accentSoft:'#e3dbf3', accentLine:'#bda9e0',
    swatches:['#dcd6e8','#f6f3fb','#8666c8'],
  },
  lilac_cream: {
    name: '丁香奶霜',
    en:   'Lilac Cream',
    bg:'#ead9ed', surface:'#fbf2fc', sunken:'#ddc8e2', elev:'#fff8ff',
    line:'#d4bcd9', lineStrong:'#b89bbe', lineSoft:'#e5d1ea',
    accent:'#a865bd', accentSoft:'#efdcf3', accentLine:'#d4a9dc',
    swatches:['#ead9ed','#fbf2fc','#a865bd'],
  },
  periwinkle_sky: {
    name: '長春花',
    en:   'Periwinkle Sky',
    bg:'#d6daee', surface:'#f1f3fc', sunken:'#c4caea', elev:'#fafbff',
    line:'#bdc3dd', lineStrong:'#9aa1c4', lineSoft:'#d3d8e8',
    accent:'#6c80d4', accentSoft:'#dde2f4', accentLine:'#a9b3df',
    swatches:['#d6daee','#f1f3fc','#6c80d4'],
  },
  mauve_dust: {
    name: '紫絨塵',
    en:   'Mauve Dust',
    bg:'#e3d4de', surface:'#faf1f5', sunken:'#d5c0cd', elev:'#fff9fc',
    line:'#caafbe', lineStrong:'#a78395', lineSoft:'#dec8d4',
    accent:'#a16b8c', accentSoft:'#eedce6', accentLine:'#cca0b6',
    swatches:['#e3d4de','#faf1f5','#a16b8c'],
  },
  wisteria_bloom: {
    name: '紫藤盛開',
    en:   'Wisteria Bloom',
    bg:'#d3c8e9', surface:'#f1ecfb', sunken:'#c0b2dd', elev:'#fbf7ff',
    line:'#b8aad3', lineStrong:'#9786b9', lineSoft:'#cdc0e0',
    accent:'#6849c6', accentSoft:'#e0d6f5', accentLine:'#b29be0',
    swatches:['#d3c8e9','#f1ecfb','#6849c6'],
  },
  heather_fog: {
    name: '石楠迷霧',
    en:   'Heather Fog',
    bg:'#d8d6e0', surface:'#f4f3f8', sunken:'#cac7d3', elev:'#fafafd',
    line:'#bfbcca', lineStrong:'#9d99ab', lineSoft:'#cfccd8',
    accent:'#7a7396', accentSoft:'#e3e0ea', accentLine:'#b4afc3',
    swatches:['#d8d6e0','#f4f3f8','#7a7396'],
  },

  // ---------------------------------------------------------------------------
  // Reading-comfort variants — all evolve from Lavender Mist (#1).
  // Principles applied (vary per variant):
  //   • Push fg darker for higher text contrast on light chrome
  //   • Soften line colors so dividers don't compete with content
  //   • Desaturate chrome (less chromatic "noise" in peripheral vision)
  //   • Try ivory / cream paper to cut LCD glare during long reads
  //   • Adjust hover/shadow tint so the whole UI feels quieter
  // ---------------------------------------------------------------------------
  paper_white: {
    name: '紙白薰衣草',
    en:   'Paper White',
    // Chrome stays lavender, but slightly less saturated than Mist.
    // Surface near-white, text pushed darker — best for clinical clarity.
    bg:'#e2dceb', surface:'#fbfaff', sunken:'#d3cce0', elev:'#ffffff',
    line:'#cfc7dd', lineStrong:'#a99ec6', lineSoft:'#dfd9e8',
    fg:'#120c1e', fgMuted:'#3f365a', fgSubtle:'#6b6286', fgFaint:'#9a91b0',
    accent:'#7a5cc0', accentSoft:'#e2d9f3', accentLine:'#b9a4dd',
    paper:'#ffffff', paperEdge:'rgba(30,20,60,0.14)',
    hover:'rgba(30,20,60,0.05)',
    swatches:['#e2dceb','#fbfaff','#7a5cc0'],
  },

  ivory_mist: {
    name: '米霧薰衣草',
    en:   'Ivory Mist',
    // Cream / ivory tones throughout — cuts blue-light glare for long reads.
    // Paper is warm ivory; chrome carries a faint lavender warmth.
    bg:'#ddd6e2', surface:'#f8f4ee', sunken:'#cec6d6', elev:'#fdfaf3',
    line:'#cdc4d2', lineStrong:'#a59ab2', lineSoft:'#dcd3df',
    fg:'#1c1626', fgMuted:'#48405e', fgSubtle:'#6e6582', fgFaint:'#9d94ad',
    accent:'#7e62c2', accentSoft:'#ebe2f0', accentLine:'#b9a3d8',
    paper:'#fcf8ef', paperEdge:'rgba(40,28,72,0.14)',
    hover:'rgba(40,28,72,0.05)',
    swatches:['#ddd6e2','#f8f4ee','#7e62c2'],
  },

  morning_frost: {
    name: '晨霜薰衣草',
    en:   'Morning Frost',
    // Slightly cooler than Mist, very crisp surfaces, strongest text contrast.
    // Reads "alert" — good for editing-focused sessions.
    bg:'#d6d2e4', surface:'#fafaff', sunken:'#c5c0d8', elev:'#ffffff',
    line:'#c0b9d2', lineStrong:'#988fb4', lineSoft:'#d6d0e0',
    fg:'#0e0918', fgMuted:'#3a3252', fgSubtle:'#665d80', fgFaint:'#958baa',
    accent:'#7559c4', accentSoft:'#dfd7f1', accentLine:'#b09bd9',
    hover:'rgba(20,12,50,0.06)',
    swatches:['#d6d2e4','#fafaff','#7559c4'],
  },

  muted_stone: {
    name: '鈍紫石',
    en:   'Muted Stone',
    // Desaturated gray-lavender — lowest chromatic noise in peripheral vision.
    // For working all day without the purple "buzzing."
    bg:'#d6d3dd', surface:'#f3f1f6', sunken:'#c7c3cf', elev:'#faf9fc',
    line:'#bdb8c7', lineStrong:'#928aa1', lineSoft:'#cdc8d4',
    fg:'#161221', fgMuted:'#433c54', fgSubtle:'#6a6377', fgFaint:'#968fa6',
    accent:'#6e5aa6', accentSoft:'#ddd6e8', accentLine:'#a99cc5',
    hover:'rgba(30,22,55,0.05)',
    swatches:['#d6d3dd','#f3f1f6','#6e5aa6'],
  },

  dawn_veil: {
    name: '薄霧朝陽',
    en:   'Dawn Veil',
    // Lifted chrome (lighter overall) + nearly invisible soft lines.
    // Calming, low-contrast dividers, slightly higher text contrast.
    bg:'#e3deec', surface:'#fcfaff', sunken:'#d7d1e3', elev:'#ffffff',
    line:'#d4cde1', lineStrong:'#aba0c6', lineSoft:'#e6e1ed',
    fg:'#1a1426', fgMuted:'#48405e', fgSubtle:'#7a7090', fgFaint:'#a89fbb',
    accent:'#8868c8', accentSoft:'#e8e0f5', accentLine:'#c4b1e2',
    hover:'rgba(40,28,72,0.04)',
    shadowSm:'0 1px 2px rgba(40,28,72,0.05)',
    shadowMd:'0 4px 12px rgba(40,28,72,0.08), 0 1px 2px rgba(40,28,72,0.05)',
    shadowLg:'0 14px 36px rgba(40,28,72,0.14), 0 2px 6px rgba(40,28,72,0.06)',
    swatches:['#e3deec','#fcfaff','#8868c8'],
  },

  deep_silk: {
    name: '深紫絹',
    en:   'Deep Silk',
    // Keeps depth between layers (deeper bg + cleaner surface).
    // Strong text contrast; paper stays white. High-fidelity, focused mood.
    bg:'#d4cde3', surface:'#f5f1fa', sunken:'#c1b6d4', elev:'#fdfaff',
    line:'#bbb1cd', lineStrong:'#988bb6', lineSoft:'#cec5dc',
    fg:'#0e0920', fgMuted:'#3a3155', fgSubtle:'#675d82', fgFaint:'#9489ad',
    accent:'#6e4ec0', accentSoft:'#e0d6f2', accentLine:'#b39fde',
    hover:'rgba(30,18,72,0.07)',
    swatches:['#d4cde3','#f5f1fa','#6e4ec0'],
  },

  // ---------------------------------------------------------------------------
  // Round 3 — Pale Pastel + White Panels
  // Pair Morning-Frost-level near-white surfaces with even paler, more pastel
  // chrome. Same UI structure, lower chromatic weight on the bg + sunken
  // layers so the document feels more present and the chrome recedes.
  // ---------------------------------------------------------------------------
  pale_iris: {
    name: '淡虹',
    en:   'Pale Iris',
    // Slightly cooler than Morning Frost — paler, airier chrome.
    bg:'#e6e2ef', surface:'#fafaff', sunken:'#d8d3e3', elev:'#ffffff',
    line:'#cdc6d9', lineStrong:'#a59ab8', lineSoft:'#dfdae6',
    fg:'#100b1e', fgMuted:'#3b3357', fgSubtle:'#675d82', fgFaint:'#9489ad',
    accent:'#7559c4', accentSoft:'#e2d9f3', accentLine:'#b09bd9',
    hover:'rgba(20,12,50,0.05)',
    swatches:['#e6e2ef','#fafaff','#7559c4'],
  },

  whisper_lilac: {
    name: '輕語紫丁',
    en:   'Whisper Lilac',
    // Warmer pink-leaning lavender at the chrome — like Lilac Cream lightened.
    bg:'#ece3ef', surface:'#fbfaff', sunken:'#ddd2e3', elev:'#ffffff',
    line:'#d3c8d9', lineStrong:'#ad9eb6', lineSoft:'#e2d9e6',
    fg:'#120c1e', fgMuted:'#3f3457', fgSubtle:'#6c5e82', fgFaint:'#9889ad',
    accent:'#8a5ec2', accentSoft:'#ebdef0', accentLine:'#c4a8d8',
    hover:'rgba(40,20,60,0.05)',
    swatches:['#ece3ef','#fbfaff','#8a5ec2'],
  },

  cloud_lavender: {
    name: '雲薰衣草',
    en:   'Cloud Lavender',
    // True-lavender hue, the lightest of all — chrome almost floats.
    bg:'#eae5f1', surface:'#fcfbff', sunken:'#dcd5e7', elev:'#ffffff',
    line:'#d2cbde', lineStrong:'#a89fc0', lineSoft:'#e0dae9',
    fg:'#120c1f', fgMuted:'#3d3457', fgSubtle:'#695d82', fgFaint:'#968bad',
    accent:'#7a5cc0', accentSoft:'#e6dcf3', accentLine:'#bca6dc',
    hover:'rgba(30,18,60,0.04)',
    swatches:['#eae5f1','#fcfbff','#7a5cc0'],
  },

  spring_haze: {
    name: '春霾',
    en:   'Spring Haze',
    // Periwinkle-leaning — blue-violet chrome, white panels.
    bg:'#e3e1f0', surface:'#fafbff', sunken:'#d3d0e3', elev:'#ffffff',
    line:'#cac6dd', lineStrong:'#9f9bbb', lineSoft:'#dcd9e8',
    fg:'#0f0c1e', fgMuted:'#383557', fgSubtle:'#645f82', fgFaint:'#928fad',
    accent:'#6b5fc8', accentSoft:'#dfddf3', accentLine:'#a8a0db',
    hover:'rgba(20,16,60,0.05)',
    swatches:['#e3e1f0','#fafbff','#6b5fc8'],
  },

  porcelain: {
    name: '瓷紫',
    en:   'Porcelain',
    // The most pastel — chrome barely lavender, mostly cool warm-white.
    // Lowest chromatic load; nearly monochrome on a casual glance.
    bg:'#ece9f0', surface:'#fcfbfe', sunken:'#dedae5', elev:'#ffffff',
    line:'#d4cfdb', lineStrong:'#aaa2b8', lineSoft:'#e2dde6',
    fg:'#141022', fgMuted:'#3f3759', fgSubtle:'#6c6483', fgFaint:'#9991ae',
    accent:'#7558bf', accentSoft:'#e7dff2', accentLine:'#b9a6d6',
    hover:'rgba(30,22,55,0.04)',
    swatches:['#ece9f0','#fcfbfe','#7558bf'],
  },

  fresh_air: {
    name: '清新空氣',
    en:   'Fresh Air',
    // Brightest chrome — bg only slightly tinted vs surface, but lines stay
    // distinctly lavender so structure still reads cleanly.
    bg:'#eee9f3', surface:'#ffffff', sunken:'#dfd9ea', elev:'#ffffff',
    line:'#d5cce0', lineStrong:'#aa9ec5', lineSoft:'#e3dceb',
    fg:'#0e081c', fgMuted:'#383056', fgSubtle:'#645982', fgFaint:'#9285ac',
    accent:'#7a59c7', accentSoft:'#e6dcf3', accentLine:'#b8a3dc',
    hover:'rgba(20,12,50,0.04)',
    swatches:['#eee9f3','#ffffff','#7a59c7'],
  },

  // ---------------------------------------------------------------------------
  // Round 5 — Lupine
  // Translated from the Morphous Lupine design system (魯冰花).
  // Signature DNA:
  //   • Deep blue-violet primary (#4338CA) — more saturated than our lavenders
  //   • Leaf-green focus / success (#16A34A) — the unique alpine signature
  //   • Cool alpine-snow whites with subtle violet OR meadow-green undertones
  //   • Deeper slate ink (#0F172A) for higher text contrast
  // Each variant treats the chrome tint differently — canonical → meadow →
  // lavender-mist → silver alpine → deep iris.
  // ---------------------------------------------------------------------------
  alpine_snow: {
    name: '高山雪',
    en:   'Alpine Snow',
    // Canonical Lupine — alpine-cool near-whites, indigo accent, leaf-green good.
    bg:'#f0ecfa', surface:'#fafafc', sunken:'#e2dcf2', elev:'#ffffff',
    line:'#ddd6ec', lineStrong:'#b7add0', lineSoft:'#ebe5f6',
    fg:'#0f172a', fgMuted:'#3a4358', fgSubtle:'#6b7280', fgFaint:'#9aa0ad',
    accent:'#4338ca', accentSoft:'#e0dbf3', accentLine:'#b9aee2',
    good:'#16a34a', goodSoft:'#dcfce7',
    swatches:['#f0ecfa','#fafafc','#4338ca'],
  },

  meadow_lupine: {
    name: '草甸魯冰',
    en:   'Meadow Lupine',
    // Warmer take — surfaces carry the "Meadow White" green-tinted card color
    // from the Lupine spec. Bg keeps the cool violet so the chrome reads as
    // "alpine sky over a meadow."
    bg:'#eae6f3', surface:'#f5f7f2', sunken:'#dbd6e9', elev:'#fdfdf8',
    line:'#d4d7cf', lineStrong:'#a4ab9d', lineSoft:'#e2e5dd',
    fg:'#0f172a', fgMuted:'#3a4358', fgSubtle:'#697282', fgFaint:'#969cab',
    accent:'#4338ca', accentSoft:'#e2dcf3', accentLine:'#bcaee4',
    good:'#16a34a', goodSoft:'#d8ecd9',
    swatches:['#eae6f3','#f5f7f2','#4338ca'],
  },

  petal_lupine: {
    name: '花瓣魯冰',
    en:   'Petal Lupine',
    // Lavender-mist forward — bg lifted into the spec's #F3F0FF, surface stays
    // white. Uses the lighter Petal Indigo (#6366F1) as the accent for a
    // softer, more "petal" feel.
    bg:'#f3f0ff', surface:'#ffffff', sunken:'#e6dffb', elev:'#ffffff',
    line:'#dcd5f0', lineStrong:'#b3a9d8', lineSoft:'#e9e4f7',
    fg:'#0f172a', fgMuted:'#3d3e5c', fgSubtle:'#6b6b85', fgFaint:'#9b9bb4',
    accent:'#6366f1', accentSoft:'#e2e1fc', accentLine:'#b8b8f0',
    good:'#16a34a', goodSoft:'#dcfce7',
    swatches:['#f3f0ff','#ffffff','#6366f1'],
  },

  silver_alpine: {
    name: '銀光高山',
    en:   'Silver Alpine',
    // Neutral cool grey chrome (the Lupine "Silver Light" border #D1D5DB
    // becomes the line color). Reads as a precise, OS-native tool — the
    // indigo accent and leaf-green focus carry the alpine signature.
    bg:'#eef0f3', surface:'#ffffff', sunken:'#dde0e6', elev:'#ffffff',
    line:'#d1d5db', lineStrong:'#9aa0ab', lineSoft:'#e3e5ea',
    fg:'#0f172a', fgMuted:'#384151', fgSubtle:'#646d7c', fgFaint:'#959ba8',
    accent:'#4338ca', accentSoft:'#e3def4', accentLine:'#bbb1e3',
    good:'#16a34a', goodSoft:'#d6ecdd',
    swatches:['#eef0f3','#ffffff','#4338ca'],
  },

  deep_iris_lupine: {
    name: '深虹魯冰',
    en:   'Deep Iris Lupine',
    // Strongest chromatic presence — bg pushed to a saturated lavender-mist,
    // accent at full Lupine #4338CA. For users who like the petal color to
    // dominate the chrome (closer to our existing 紫藤盛開, but with
    // Lupine's deeper ink and leaf-green ring).
    bg:'#e6dff8', surface:'#f6f3fc', sunken:'#d2c8ec', elev:'#fcfaff',
    line:'#c8bde2', lineStrong:'#9d8fc6', lineSoft:'#d8cfe8',
    fg:'#0f172a', fgMuted:'#3a3658', fgSubtle:'#6b6585', fgFaint:'#9a93b4',
    accent:'#4338ca', accentSoft:'#dccff3', accentLine:'#b099db',
    good:'#16a34a', goodSoft:'#dcfce7',
    swatches:['#e6dff8','#f6f3fc','#4338ca'],
  },

  // ---------------------------------------------------------------------------
  // Round 4 — Dark Mode variants
  // Same lavender DNA as the pale palettes, but inverted: medium-dark chrome,
  // deeper canvas well, lifted popovers. Paper stays ivory to reduce LCD glare
  // in dim rooms (the only thing that's "white" on screen is the document).
  // Two of these are designated as official modes, mirroring 淡虹 / 瓷紫:
  //   • 01 深夜虹  → 專注模式 Concentration  (mirror of pale_iris)
  //   • 05 墨瓷    → 低視覺負擔 Low Visual Burden (mirror of porcelain)
  // ---------------------------------------------------------------------------
  midnight_iris: {
    name: '深夜虹',
    en:   'Midnight Iris',
    isDark: true,
    // Cool, crisp, clearest separation between layers — best for editing focus.
    bg:'#181522', surface:'#221f2f', sunken:'#0f0d18', elev:'#2a2638',
    line:'#2e2a3d', lineStrong:'#4a455e', lineSoft:'#211d2d',
    fg:'#ecebf5', fgMuted:'#a8a3c4', fgSubtle:'#756f93', fgFaint:'#4d4866',
    accent:'#a48ee0', accentFg:'#0f0c1a',
    accentSoft:'rgba(164,142,224,0.14)', accentLine:'rgba(164,142,224,0.38)',
    paper:'#f1efe8', paperEdge:'rgba(0,0,0,0.55)',
    hover:'rgba(255,255,255,0.05)', hoverStrong:'rgba(255,255,255,0.09)',
    shadowSm:'0 1px 2px rgba(0,0,0,0.45)',
    shadowMd:'0 4px 14px rgba(0,0,0,0.40), 0 1px 2px rgba(0,0,0,0.30)',
    shadowLg:'0 14px 36px rgba(0,0,0,0.55), 0 2px 6px rgba(0,0,0,0.35)',
    swatches:['#181522','#221f2f','#a48ee0'],
  },

  ink_silk: {
    name: '墨絲',
    en:   'Ink Silk',
    isDark: true,
    // Deepest contrast — rich purple-black with luminous lavender accent.
    // For OLED screens and high-fidelity work.
    bg:'#15121f', surface:'#1f1b2b', sunken:'#0a0810', elev:'#2a2438',
    line:'#2b2738', lineStrong:'#453f58', lineSoft:'#1e1a28',
    fg:'#f0eef9', fgMuted:'#b0a8c8', fgSubtle:'#7c7396', fgFaint:'#524a68',
    accent:'#b395ec', accentFg:'#0a0612',
    accentSoft:'rgba(179,149,236,0.16)', accentLine:'rgba(179,149,236,0.42)',
    paper:'#f4f1eb', paperEdge:'rgba(0,0,0,0.6)',
    hover:'rgba(255,255,255,0.05)', hoverStrong:'rgba(255,255,255,0.09)',
    shadowSm:'0 1px 2px rgba(0,0,0,0.5)',
    shadowMd:'0 4px 14px rgba(0,0,0,0.45), 0 1px 2px rgba(0,0,0,0.35)',
    shadowLg:'0 16px 40px rgba(0,0,0,0.60), 0 2px 6px rgba(0,0,0,0.40)',
    swatches:['#15121f','#1f1b2b','#b395ec'],
  },

  velvet_dusk: {
    name: '紫絨夜',
    en:   'Velvet Dusk',
    isDark: true,
    // Warmer, slightly pink-leaning — evening mood, gentle saturation.
    bg:'#1e1828', surface:'#2a2336', sunken:'#16111e', elev:'#322a42',
    line:'#3a3348', lineStrong:'#4d4562', lineSoft:'#2a2434',
    fg:'#ebe4f3', fgMuted:'#b3a6c8', fgSubtle:'#847795', fgFaint:'#594f68',
    accent:'#c79bd8', accentFg:'#120a18',
    accentSoft:'rgba(199,155,216,0.16)', accentLine:'rgba(199,155,216,0.38)',
    paper:'#ede8df', paperEdge:'rgba(0,0,0,0.5)',
    hover:'rgba(255,255,255,0.05)', hoverStrong:'rgba(255,255,255,0.09)',
    shadowSm:'0 1px 2px rgba(0,0,0,0.4)',
    shadowMd:'0 4px 12px rgba(0,0,0,0.35), 0 1px 2px rgba(0,0,0,0.25)',
    shadowLg:'0 12px 32px rgba(0,0,0,0.50), 0 2px 6px rgba(0,0,0,0.30)',
    swatches:['#1e1828','#2a2336','#c79bd8'],
  },

  twilight_mist: {
    name: '暮霧紫',
    en:   'Twilight Mist',
    isDark: true,
    // Soft lifted — lower contrast, calmer dividers, slightly elevated overall.
    // The reading-friendly dark variant.
    bg:'#24202e', surface:'#2e2a3a', sunken:'#1a1623', elev:'#363145',
    line:'#3a364a', lineStrong:'#4c485e', lineSoft:'#2c2838',
    fg:'#e0d9ea', fgMuted:'#a89eba', fgSubtle:'#7a7090', fgFaint:'#564e68',
    accent:'#a88fce', accentFg:'#120a1e',
    accentSoft:'rgba(168,143,206,0.14)', accentLine:'rgba(168,143,206,0.32)',
    paper:'#ede8df', paperEdge:'rgba(0,0,0,0.45)',
    hover:'rgba(255,255,255,0.04)', hoverStrong:'rgba(255,255,255,0.08)',
    shadowSm:'0 1px 2px rgba(0,0,0,0.35)',
    shadowMd:'0 4px 12px rgba(0,0,0,0.30), 0 1px 2px rgba(0,0,0,0.22)',
    shadowLg:'0 12px 30px rgba(0,0,0,0.42), 0 2px 6px rgba(0,0,0,0.26)',
    swatches:['#24202e','#2e2a3a','#a88fce'],
  },

  ink_porcelain: {
    name: '墨瓷',
    en:   'Ink Porcelain',
    isDark: true,
    // Mirror of 瓷紫 — nearly neutral charcoal, only the faintest violet whisper.
    // Lowest chromatic load; reads as a serious neutral dark UI at a glance.
    bg:'#18171c', surface:'#232228', sunken:'#101015', elev:'#2a2931',
    line:'#2b2a33', lineStrong:'#403e49', lineSoft:'#211f26',
    fg:'#e8e7eb', fgMuted:'#a39fad', fgSubtle:'#6f6c78', fgFaint:'#494754',
    accent:'#9b8fc0', accentFg:'#0d0c12',
    accentSoft:'rgba(155,143,192,0.13)', accentLine:'rgba(155,143,192,0.32)',
    paper:'#f1efe8', paperEdge:'rgba(0,0,0,0.5)',
    hover:'rgba(255,255,255,0.04)', hoverStrong:'rgba(255,255,255,0.07)',
    shadowSm:'0 1px 2px rgba(0,0,0,0.45)',
    shadowMd:'0 4px 12px rgba(0,0,0,0.40), 0 1px 2px rgba(0,0,0,0.28)',
    shadowLg:'0 12px 32px rgba(0,0,0,0.55), 0 2px 6px rgba(0,0,0,0.32)',
    swatches:['#18171c','#232228','#9b8fc0'],
  },
};

const THEMES = {
  light: {
    // Surfaces — soft pastel, but with real separation between bg and toolbars
    bg:        '#dcd6e8',   // desktop / chrome — deeper muted lavender
    surface:   '#f6f3fb',   // toolbars / panels — clearly lighter than bg
    sunken:    '#cfc7df',   // canvas well behind pages — deepest
    elev:      '#fcfaff',   // popovers, menus
    // Borders — visible but still soft
    line:      '#c6bfd6',
    lineStrong:'#a89dc4',
    lineSoft:  '#d8d1e4',
    // Text — darker so it reads cleanly on the pastel chrome
    fg:        '#1f1a2e',
    fgMuted:   '#564f6e',
    fgSubtle:  '#7d7592',
    fgFaint:   '#a89fbb',
    // Accent — soft lavender purple, more saturated than before
    accent:    '#8666c8',
    accentFg:  '#ffffff',
    accentSoft:'#e3dbf3',
    accentLine:'#bda9e0',
    // Mode-specific tints — pastels (mint / peach / blush)
    warn:      '#a86a3a',
    warnSoft:  '#f3e1cf',
    good:      '#5e8e76',
    goodSoft:  '#d8e6dd',
    danger:    '#a85f5f',
    dangerSoft:'#ecd2d2',
    highlight: '#f0d670',   // 螢光筆
    // Hovers
    hover:     'rgba(40,28,72,0.06)',
    hoverStrong:'rgba(40,28,72,0.10)',
    pressed:   'rgba(40,28,72,0.14)',
    // Shadows — soft, slightly violet-tinted
    shadowSm:  '0 1px 2px rgba(40,28,72,0.06)',
    shadowMd:  '0 4px 12px rgba(40,28,72,0.10), 0 1px 2px rgba(40,28,72,0.06)',
    shadowLg:  '0 14px 36px rgba(40,28,72,0.18), 0 2px 6px rgba(40,28,72,0.08)',
    // Paper
    paper:     '#ffffff',
    paperEdge: 'rgba(40,28,72,0.12)',
  },
  dark: {
    bg:        '#0e1014',
    surface:   '#161a20',
    sunken:    '#0b0d10',
    elev:      '#1c2027',
    line:      '#262b33',
    lineStrong:'#323842',
    lineSoft:  '#1d2128',
    fg:        '#e8eaed',
    fgMuted:   '#a0a6b0',
    fgSubtle:  '#757b86',
    fgFaint:   '#525763',
    accent:    '#6b8eff',
    accentFg:  '#0b0d10',
    accentSoft:'rgba(107,142,255,0.12)',
    accentLine:'rgba(107,142,255,0.32)',
    warn:      '#d99353',
    warnSoft:  'rgba(217,147,83,0.12)',
    good:      '#5db98c',
    goodSoft:  'rgba(93,185,140,0.12)',
    danger:    '#e26a6a',
    dangerSoft:'rgba(226,106,106,0.12)',
    highlight: '#e6c62c',
    hover:     'rgba(255,255,255,0.05)',
    hoverStrong:'rgba(255,255,255,0.08)',
    pressed:   'rgba(255,255,255,0.12)',
    shadowSm:  '0 1px 2px rgba(0,0,0,0.4)',
    shadowMd:  '0 4px 12px rgba(0,0,0,0.35), 0 1px 2px rgba(0,0,0,0.25)',
    shadowLg:  '0 12px 32px rgba(0,0,0,0.45), 0 2px 6px rgba(0,0,0,0.30)',
    paper:     '#f1efe8',   // ivory paper, easier on eyes in dark UI
    paperEdge: 'rgba(0,0,0,0.35)',
  },
};

const DENSITY = {
  comfortable: { row: 32, rowSm: 26, px: 10, gap: 8,  ribbonH: 60, tabH: 34, railW: 56 },
  compact:     { row: 28, rowSm: 22, px: 8,  gap: 6,  ribbonH: 52, tabH: 30, railW: 48 },
};

// Central context & accessor
const ThemeCtx = React.createContext(null);
function useTheme() { return React.useContext(ThemeCtx); }

function ThemeProvider({ theme = 'light', density = 'comfortable', accent, palette, children }) {
  const base = THEMES[theme] || THEMES.light;
  const t = React.useMemo(() => {
    const out = { ...base, _mode: theme, _density: DENSITY[density] || DENSITY.comfortable };
    // Palette override — light palettes apply on light theme, dark palettes apply on dark theme.
    // Each palette opts in to dark via `isDark: true`.
    if (palette) {
      const p = typeof palette === 'string' ? PALETTES[palette] : palette;
      const paletteIsDark = !!(p && p.isDark);
      if (p && paletteIsDark === (theme === 'dark')) {
        Object.keys(p).forEach(k => {
          if (k === 'name' || k === 'en' || k === 'swatches' || k === 'isDark') return;
          out[k] = p[k];
        });
        out._paletteId   = typeof palette === 'string' ? palette : null;
        out._paletteName = p.name;
        out._paletteEn   = p.en;
        out._swatches    = p.swatches;
        out._paletteIsDark = paletteIsDark;
      }
    }
    if (accent) {
      out.accent = accent;
      // naive soft tint from accent — good enough for a mock
      out.accentSoft = theme === 'dark' ? hexA(accent, 0.14) : hexA(accent, 0.10);
      out.accentLine = theme === 'dark' ? hexA(accent, 0.32) : hexA(accent, 0.28);
    }
    return out;
  }, [theme, density, accent, palette, base]);
  return <ThemeCtx.Provider value={t}>{children}</ThemeCtx.Provider>;
}

function hexA(hex, a) {
  const h = hex.replace('#','');
  const n = h.length === 3 ? h.split('').map(c => c+c).join('') : h;
  const r = parseInt(n.slice(0,2),16), g = parseInt(n.slice(2,4),16), b = parseInt(n.slice(4,6),16);
  return `rgba(${r},${g},${b},${a})`;
}

window.ThemeProvider = ThemeProvider;
window.useTheme = useTheme;
window.hexA = hexA;
window.PALETTES = PALETTES;
