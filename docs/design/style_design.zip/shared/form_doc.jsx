/* global React, useTheme */
// =============================================================================
// Sample PDF document: a Traditional Chinese government form
// (戶籍謄本申請書 — Household Registration Transcript Application)
// Rendered as an SVG page so it looks like real PDF content, with selectable
// "text blocks" the app can highlight, edit inline, and annotate.
//
// Each <TextBlock> exposes hit geometry so hover/select/edit modes work.
// =============================================================================

function FormPage({
  mode = 'browse',
  selectedBlockId = null,
  hoveredBlockId = null,
  editingBlockId = null,
  editingValue = '',
  onBlockHover = () => {},
  onBlockClick = () => {},
  onEditChange = () => {},
  onEditCommit = () => {},
  annotations = [],
  highlights = [],
  showBlockOutlines = false,
  pageNumber = 1,
  watermark = null,
  filledValues = {},
}) {
  const t = useTheme();

  // Layout: A4 portrait — 595 × 842 pt. We render at 1:1 and let the host scale.
  const W = 595, H = 842;

  // All field data is centralised so "text selection / edit" is driven by id.
  return (
    <div
      style={{
        position: 'relative',
        width: W, height: H,
        background: t.paper,
        boxShadow: `0 0 0 1px ${t.paperEdge}, 0 12px 36px rgba(0,0,0,0.10)`,
        borderRadius: 2,
        overflow: 'hidden',
        fontFamily: 'var(--font-tc)',
        color: '#18181b',
      }}
    >
      <svg viewBox={`0 0 ${W} ${H}`} width={W} height={H} style={{ display: 'block' }}>
        {/* Header rule */}
        <line x1="48" y1="92" x2={W-48} y2="92" stroke="#111" strokeWidth="1.4"/>
        <line x1="48" y1="96" x2={W-48} y2="96" stroke="#111" strokeWidth="0.6"/>

        {/* Agency seal placeholder (top-right circle stamp) */}
        <g transform={`translate(${W-110},40)`}>
          <circle cx="28" cy="28" r="26" fill="none" stroke="#c23b3b" strokeWidth="1.2"/>
          <circle cx="28" cy="28" r="22" fill="none" stroke="#c23b3b" strokeWidth="0.8"/>
          <text x="28" y="22" textAnchor="middle" fontSize="8" fill="#c23b3b" fontFamily="var(--font-tc)">中華民國</text>
          <text x="28" y="33" textAnchor="middle" fontSize="10" fill="#c23b3b" fontWeight="600" fontFamily="var(--font-tc)">戶政</text>
          <text x="28" y="42" textAnchor="middle" fontSize="6" fill="#c23b3b" fontFamily="var(--font-tc)">核驗章</text>
        </g>

        {/* Title */}
        <text x={W/2} y="62" textAnchor="middle" fontSize="22" fontWeight="600" fontFamily="var(--font-tc)" fill="#111" letterSpacing="6">戶籍謄本申請書</text>
        <text x={W/2} y="82" textAnchor="middle" fontSize="10" fontFamily="var(--font-tc)" fill="#444">Application for Household Registration Transcript</text>

        {/* Form number + date strip */}
        <text x="48"   y="118" fontSize="9.5" fontFamily="var(--font-tc)" fill="#555">表單編號　HR-114-03</text>
        <text x={W-48} y="118" textAnchor="end" fontSize="9.5" fontFamily="var(--font-tc)" fill="#555">中華民國 114 年 4 月 23 日</text>
      </svg>

      {/* Absolutely-positioned form rows — these are the "text blocks" the editor sees */}
      <FormSection title="一、申請人基本資料　Applicant" top={140}>
        <Row>
          <Cell w={0.5}>
            <FieldLabel>姓名　<Muted>Name</Muted></FieldLabel>
            <FieldValue
              id="name"
              mode={mode} selectedBlockId={selectedBlockId} hoveredBlockId={hoveredBlockId}
              editingBlockId={editingBlockId} editingValue={editingValue}
              onBlockHover={onBlockHover} onBlockClick={onBlockClick}
              onEditChange={onEditChange} onEditCommit={onEditCommit}
              showBlockOutlines={showBlockOutlines}
              value={filledValues.name ?? '王　小明'}
            />
          </Cell>
          <Cell w={0.25}>
            <FieldLabel>性別　<Muted>Sex</Muted></FieldLabel>
            <FieldValue id="sex" mode={mode} selectedBlockId={selectedBlockId} hoveredBlockId={hoveredBlockId}
              editingBlockId={editingBlockId} editingValue={editingValue}
              onBlockHover={onBlockHover} onBlockClick={onBlockClick}
              onEditChange={onEditChange} onEditCommit={onEditCommit}
              showBlockOutlines={showBlockOutlines}
              value={filledValues.sex ?? '男'} />
          </Cell>
          <Cell w={0.25}>
            <FieldLabel>出生日期　<Muted>DOB</Muted></FieldLabel>
            <FieldValue id="dob" mode={mode} selectedBlockId={selectedBlockId} hoveredBlockId={hoveredBlockId}
              editingBlockId={editingBlockId} editingValue={editingValue}
              onBlockHover={onBlockHover} onBlockClick={onBlockClick}
              onEditChange={onEditChange} onEditCommit={onEditCommit}
              showBlockOutlines={showBlockOutlines}
              value={filledValues.dob ?? '民國 80 年 06 月 14 日'} />
          </Cell>
        </Row>
        <Row>
          <Cell w={0.5}>
            <FieldLabel>身分證字號　<Muted>National ID</Muted></FieldLabel>
            <FieldValue id="natid" mono mode={mode} selectedBlockId={selectedBlockId} hoveredBlockId={hoveredBlockId}
              editingBlockId={editingBlockId} editingValue={editingValue}
              onBlockHover={onBlockHover} onBlockClick={onBlockClick}
              onEditChange={onEditChange} onEditCommit={onEditCommit}
              showBlockOutlines={showBlockOutlines}
              value={filledValues.natid ?? 'A123456789'} />
          </Cell>
          <Cell w={0.5}>
            <FieldLabel>聯絡電話　<Muted>Phone</Muted></FieldLabel>
            <FieldValue id="phone" mono mode={mode} selectedBlockId={selectedBlockId} hoveredBlockId={hoveredBlockId}
              editingBlockId={editingBlockId} editingValue={editingValue}
              onBlockHover={onBlockHover} onBlockClick={onBlockClick}
              onEditChange={onEditChange} onEditCommit={onEditCommit}
              showBlockOutlines={showBlockOutlines}
              value={filledValues.phone ?? '(02) 2345-6789　/　0912-345-678'} />
          </Cell>
        </Row>
        <Row>
          <Cell w={1}>
            <FieldLabel>戶籍地址　<Muted>Registered Address</Muted></FieldLabel>
            <FieldValue id="addr" mode={mode} selectedBlockId={selectedBlockId} hoveredBlockId={hoveredBlockId}
              editingBlockId={editingBlockId} editingValue={editingValue}
              onBlockHover={onBlockHover} onBlockClick={onBlockClick}
              onEditChange={onEditChange} onEditCommit={onEditCommit}
              showBlockOutlines={showBlockOutlines}
              value={filledValues.addr ?? '臺北市大安區信義路三段 134 巷 12 號 5 樓之 2'} />
          </Cell>
        </Row>
      </FormSection>

      <FormSection title="二、申請項目　Requested Items" top={330}>
        <CheckRow checked label="戶籍謄本（現戶全戶）" en="Current household, all members"/>
        <CheckRow checked label="戶籍謄本（現戶個人）" en="Current household, individual"/>
        <CheckRow label="戶籍謄本（全戶歷次記事）" en="All historical records"/>
        <CheckRow label="除戶戶籍謄本" en="Removed household transcript"/>
        <Row>
          <Cell w={0.5}>
            <FieldLabel>申請份數　<Muted>Copies</Muted></FieldLabel>
            <FieldValue id="copies" mono mode={mode} selectedBlockId={selectedBlockId} hoveredBlockId={hoveredBlockId}
              editingBlockId={editingBlockId} editingValue={editingValue}
              onBlockHover={onBlockHover} onBlockClick={onBlockClick}
              onEditChange={onEditChange} onEditCommit={onEditCommit}
              showBlockOutlines={showBlockOutlines}
              value={filledValues.copies ?? '三 份'} />
          </Cell>
          <Cell w={0.5}>
            <FieldLabel>用途　<Muted>Purpose</Muted></FieldLabel>
            <FieldValue id="purpose" mode={mode} selectedBlockId={selectedBlockId} hoveredBlockId={hoveredBlockId}
              editingBlockId={editingBlockId} editingValue={editingValue}
              onBlockHover={onBlockHover} onBlockClick={onBlockClick}
              onEditChange={onEditChange} onEditCommit={onEditCommit}
              showBlockOutlines={showBlockOutlines}
              value={filledValues.purpose ?? '辦理房屋貸款，送交台灣銀行審查用'} />
          </Cell>
        </Row>
      </FormSection>

      <FormSection title="三、委託代理人　Authorised Representative" top={540}>
        <Row>
          <Cell w={0.5}>
            <FieldLabel>代理人姓名　<Muted>Agent Name</Muted></FieldLabel>
            <FieldValue id="agent" mode={mode} selectedBlockId={selectedBlockId} hoveredBlockId={hoveredBlockId}
              editingBlockId={editingBlockId} editingValue={editingValue}
              onBlockHover={onBlockHover} onBlockClick={onBlockClick}
              onEditChange={onEditChange} onEditCommit={onEditCommit}
              showBlockOutlines={showBlockOutlines}
              value={filledValues.agent ?? '林　佩君'} />
          </Cell>
          <Cell w={0.5}>
            <FieldLabel>與申請人關係　<Muted>Relationship</Muted></FieldLabel>
            <FieldValue id="rel" mode={mode} selectedBlockId={selectedBlockId} hoveredBlockId={hoveredBlockId}
              editingBlockId={editingBlockId} editingValue={editingValue}
              onBlockHover={onBlockHover} onBlockClick={onBlockClick}
              onEditChange={onEditChange} onEditCommit={onEditCommit}
              showBlockOutlines={showBlockOutlines}
              value={filledValues.rel ?? '配偶'} />
          </Cell>
        </Row>
        <Row>
          <Cell w={1}>
            <FieldLabel>備註　<Muted>Remarks</Muted></FieldLabel>
            <FieldValue id="note" multiline mode={mode} selectedBlockId={selectedBlockId} hoveredBlockId={hoveredBlockId}
              editingBlockId={editingBlockId} editingValue={editingValue}
              onBlockHover={onBlockHover} onBlockClick={onBlockClick}
              onEditChange={onEditChange} onEditCommit={onEditCommit}
              showBlockOutlines={showBlockOutlines}
              value={filledValues.note ?? '本人無法親自辦理，委由配偶代為申請，並提供雙方身分證明文件正本供核驗。'} />
          </Cell>
        </Row>
      </FormSection>

      <FormSection title="四、簽章　Signatures" top={700} dense>
        <div style={{ display: 'flex', gap: 24 }}>
          <SignatureBox label="申請人簽章" en="Applicant" stamp="王小明"/>
          <SignatureBox label="代理人簽章" en="Agent" stamp="林佩君" soft/>
          <SignatureBox label="受理機關"   en="Receiving Office" soft/>
        </div>
      </FormSection>

      {/* Footer */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 20,
        textAlign: 'center', fontSize: 8.5, color: '#8a8f99',
        fontFamily: 'var(--font-tc)',
      }}>
        內政部戶政司　印製　　HR-114-03　　　　　　　　　　　第 {pageNumber} 頁　共 1 頁
      </div>

      {/* Highlights layer */}
      {highlights.map((h, i) => (
        <div key={`hl-${i}`} style={{
          position: 'absolute', left: h.x, top: h.y, width: h.w, height: h.h,
          background: h.color || t.highlight, opacity: 0.45, borderRadius: 2,
          pointerEvents: 'none',
        }}/>
      ))}

      {/* Annotation notes layer */}
      {annotations.map((a, i) => (
        <StickyNote key={`an-${i}`} x={a.x} y={a.y} text={a.text} author={a.author}/>
      ))}

      {/* Watermark */}
      {watermark && (
        <div style={{
          position: 'absolute', inset: 0, pointerEvents: 'none',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          transform: `rotate(${watermark.angle || -30}deg)`,
        }}>
          <div style={{
            fontFamily: 'var(--font-tc)', fontWeight: 600,
            fontSize: watermark.size || 92,
            color: '#000', opacity: (watermark.opacity ?? 12) / 100,
            letterSpacing: 12, whiteSpace: 'nowrap',
          }}>{watermark.text}</div>
        </div>
      )}
    </div>
  );
}

function FormSection({ title, top, children, dense }) {
  return (
    <div style={{
      position: 'absolute', left: 48, top, right: 48,
    }}>
      <div style={{
        fontFamily: 'var(--font-tc)', fontSize: 12, fontWeight: 600,
        color: '#111', borderLeft: '3px solid #111', paddingLeft: 8,
        marginBottom: dense ? 8 : 12,
      }}>{title}</div>
      {children}
    </div>
  );
}

function Row({ children }) {
  return <div style={{ display: 'flex', gap: 12, marginBottom: 10 }}>{children}</div>;
}
function Cell({ w, children }) {
  return <div style={{ flex: `${w} 1 0`, minWidth: 0 }}>{children}</div>;
}
function FieldLabel({ children }) {
  return <div style={{ fontSize: 9, color: '#555', marginBottom: 3, letterSpacing: 0.4 }}>{children}</div>;
}
function Muted({ children }) {
  return <span style={{ color: '#9097a0', fontSize: 8.5 }}>{children}</span>;
}

function FieldValue({
  id, value, mono, multiline,
  mode, selectedBlockId, hoveredBlockId, editingBlockId, editingValue,
  onBlockHover, onBlockClick, onEditChange, onEditCommit, showBlockOutlines,
}) {
  const t = useTheme();
  const isHover = hoveredBlockId === id;
  const isSelected = selectedBlockId === id;
  const isEditing = editingBlockId === id;
  const interactive = mode !== 'browse' || true; // always allow hover/select for demo

  const outline = (() => {
    if (isEditing) return `1.5px solid ${t.accent}`;
    if (isSelected) return `1.5px solid ${t.accent}`;
    if (isHover && (mode === 'edit_text' || mode === 'browse')) return `1px solid ${t.accent}`;
    if (showBlockOutlines) return `1px dashed ${t.accentLine}`;
    return '1px solid transparent';
  })();

  const bg = (() => {
    if (isEditing) return '#fff';
    if (isSelected) return t.accentSoft;
    if (isHover && mode === 'browse') return 'rgba(43,91,217,0.06)';
    return 'transparent';
  })();

  return (
    <div
      onMouseEnter={() => onBlockHover(id)}
      onMouseLeave={() => onBlockHover(null)}
      onClick={(e) => { e.stopPropagation(); onBlockClick(id); }}
      style={{
        fontFamily: mono ? 'var(--font-mono)' : 'var(--font-tc)',
        fontSize: mono ? 12.5 : 13.5,
        color: '#111',
        borderBottom: '1px solid #111',
        padding: '4px 6px',
        paddingBottom: 6,
        minHeight: multiline ? 44 : 22,
        whiteSpace: multiline ? 'pre-wrap' : 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        cursor: mode === 'browse' ? 'text' : (mode === 'edit_text' ? 'text' : 'pointer'),
        outline,
        outlineOffset: 1,
        borderRadius: 1,
        background: bg,
        transition: 'background .12s, outline-color .12s',
        userSelect: mode === 'browse' ? 'text' : 'none',
      }}
    >
      {isEditing ? (
        multiline ? (
          <textarea
            autoFocus
            value={editingValue}
            onChange={(e) => onEditChange(e.target.value)}
            onBlur={onEditCommit}
            onKeyDown={(e) => {
              if (e.key === 'Escape') onEditCommit();
              if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) onEditCommit();
            }}
            style={{
              width: '100%', minHeight: 40, border: 'none', outline: 'none',
              background: 'transparent', resize: 'none',
              font: 'inherit', color: 'inherit',
            }}
          />
        ) : (
          <input
            autoFocus
            value={editingValue}
            onChange={(e) => onEditChange(e.target.value)}
            onBlur={onEditCommit}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === 'Escape') onEditCommit();
            }}
            style={{
              width: '100%', border: 'none', outline: 'none',
              background: 'transparent', font: 'inherit', color: 'inherit', padding: 0,
            }}
          />
        )
      ) : value}
    </div>
  );
}

function CheckRow({ checked, label, en }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
      <div style={{
        width: 13, height: 13, border: '1.2px solid #111', borderRadius: 2,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 10, color: '#111', background: '#fff',
      }}>{checked ? '✓' : ''}</div>
      <span style={{ fontFamily: 'var(--font-tc)', fontSize: 12, color: '#111' }}>
        {label} <span style={{ color: '#8a8f99' }}>　{en}</span>
      </span>
    </div>
  );
}

function SignatureBox({ label, en, stamp, soft }) {
  return (
    <div style={{
      flex: 1,
      border: `1px solid #111`,
      borderRadius: 2,
      padding: '10px 12px 36px',
      position: 'relative',
      background: '#fff',
      fontFamily: 'var(--font-tc)',
    }}>
      <div style={{ fontSize: 11, color: '#111', marginBottom: 2 }}>{label}</div>
      <div style={{ fontSize: 8.5, color: '#888' }}>{en}</div>
      {stamp && !soft && (
        <div style={{
          position: 'absolute', right: 14, bottom: 10,
          fontFamily: 'var(--font-serif)', fontWeight: 600, fontSize: 22,
          color: '#c23b3b', transform: 'rotate(-6deg)',
          border: '1.8px solid #c23b3b', padding: '2px 8px', borderRadius: 2,
          opacity: 0.88,
        }}>{stamp}</div>
      )}
    </div>
  );
}

function StickyNote({ x, y, text, author }) {
  return (
    <div style={{
      position: 'absolute', left: x, top: y, zIndex: 5,
      background: '#fff7c2', border: '1px solid #d6c67a',
      borderRadius: 4, padding: '6px 8px',
      maxWidth: 180, fontSize: 10.5, color: '#2a2a2a',
      fontFamily: 'var(--font-tc)',
      boxShadow: '0 2px 6px rgba(0,0,0,0.12)',
    }}>
      <div style={{ fontWeight: 600, fontSize: 9.5, color: '#6a5a00', marginBottom: 2 }}>
        {author || '審核員'}
      </div>
      {text}
    </div>
  );
}

window.FormPage = FormPage;
window.BLOCK_IDS = ['name', 'sex', 'dob', 'natid', 'phone', 'addr', 'copies', 'purpose', 'agent', 'rel', 'note'];
