/* global React, useTheme, Icon, FormPage, useEditorState, hexA */
// =============================================================================
// V2 — Rail + Contextual
// A bolder rethink: keeps the ribbon tabs (per user request) but slims them,
// and adds a VS-Code-style activity rail on the far left. The ribbon morphs
// to the ACTIVE MODE instead of the active tab-set alone: pick a tool in the
// rail and the top strip becomes the settings for that tool.
//
// Layout:
//   [ title bar ............................................ ]
//   [ ribbon tabs (檔案/常用/編輯/頁面/轉換) + quick bar ..... ]
//   [ contextual strip — changes with mode                    ]
//   [ doc tabs                                                ]
//   [ rail | left panel | canvas | right inspector            ]
//   [ status bar                                              ]
// =============================================================================

function V2RailContextual({ state }) {
  const t = useTheme();
  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      background: t.bg, color: t.fg, fontFamily: 'var(--font-tc)', fontSize: 13,
      borderRadius: 8, overflow: 'hidden',
      boxShadow: t.shadowLg, border: `1px solid ${t.lineStrong}`,
    }}>
      <V2TitleBar state={state}/>
      <V2Ribbon state={state}/>
      <V2Contextual state={state}/>
      <V2DocTabs state={state}/>
      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        <V2Rail state={state}/>
        {state.leftOpen && <V2LeftPanel state={state}/>}
        <V2Canvas state={state}/>
        {state.rightOpen && <V2Inspector state={state}/>}
      </div>
      <V2Status state={state}/>
    </div>
  );
}

// -----------------------------------------------------------------------------
function V2TitleBar({ state }) {
  const t = useTheme();
  return (
    <div style={{
      height: 36, display: 'flex', alignItems: 'center',
      background: t.surface, borderBottom: `1px solid ${t.lineSoft}`,
      fontSize: 12, color: t.fgMuted,
    }}>
      <div style={{ width: 56, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{
          width: 22, height: 22, borderRadius: 6,
          background: `linear-gradient(135deg, ${t.accent}, #0a0f1f)`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#fff', fontSize: 10, fontWeight: 600, letterSpacing: 0.5,
        }}>PDF</div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, flex: 1 }}>
        <span style={{ fontWeight: 500, color: t.fg }}>戶籍謄本申請書.pdf</span>
        <span style={{ color: t.fgFaint }}>·</span>
        <span style={{ color: t.fgSubtle }}>~/Documents/申請表</span>
        <span style={{
          marginLeft: 8, padding: '1px 6px', fontSize: 10,
          background: t.accentSoft, color: t.accent,
          borderRadius: 3, letterSpacing: 0.4,
        }}>有未儲存變更</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, paddingRight: 10, fontSize: 11 }}>
        <span style={{ color: t.fgSubtle }}>
          <kbd style={kbdStyle(t)}>Ctrl</kbd> <kbd style={kbdStyle(t)}>K</kbd>　快速指令
        </span>
      </div>
      <div style={{ display: 'flex' }}>
        <V2WinBtn><Icon.winMin/></V2WinBtn>
        <V2WinBtn><Icon.winMax/></V2WinBtn>
        <V2WinBtn danger><Icon.winX/></V2WinBtn>
      </div>
    </div>
  );
}
function kbdStyle(t) {
  return {
    display: 'inline-block', padding: '0 4px', fontFamily: 'var(--font-mono)',
    fontSize: 10, color: t.fgMuted, background: t.bg,
    border: `1px solid ${t.line}`, borderRadius: 3,
  };
}
function V2WinBtn({ children, danger }) {
  const t = useTheme();
  const [h, setH] = React.useState(false);
  return (
    <div onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{
        width: 46, height: 36, display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: danger && h ? '#fff' : t.fgMuted,
        background: h ? (danger ? '#e53935' : t.hover) : 'transparent', cursor: 'default',
      }}>{children}</div>
  );
}

// -----------------------------------------------------------------------------
function V2Ribbon({ state }) {
  const t = useTheme();
  const tabs = [
    { id: 'file',    label: '檔案' },
    { id: 'common',  label: '常用' },
    { id: 'edit',    label: '編輯' },
    { id: 'page',    label: '頁面' },
    { id: 'convert', label: '轉換' },
  ];
  return (
    <div style={{
      display: 'flex', alignItems: 'center',
      height: 34, background: t.surface, borderBottom: `1px solid ${t.lineSoft}`,
      padding: '0 12px 0 56px',
    }}>
      {tabs.map(tab => (
        <V2RibbonTab key={tab.id} active={state.ribbonTab === tab.id}
          onClick={() => state.setRibbonTab(tab.id)}>{tab.label}</V2RibbonTab>
      ))}
      <div style={{ flex: 1 }}/>
      <div style={{ display: 'flex', alignItems: 'center', gap: 0, fontSize: 11.5, color: t.fgMuted }}>
        <V2QuickBtn onClick={() => {}}><Icon.undo/></V2QuickBtn>
        <V2QuickBtn dim><Icon.redo/></V2QuickBtn>
        <div style={{ width: 1, height: 16, background: t.line, margin: '0 6px' }}/>
        <V2QuickBtn onClick={() => state.setLeftOpen(!state.leftOpen)} active={state.leftOpen}><Icon.sidebar/></V2QuickBtn>
        <V2QuickBtn onClick={() => state.setRightOpen(!state.rightOpen)} active={state.rightOpen}><Icon.sidebarR/></V2QuickBtn>
        <V2QuickBtn><Icon.fullscreen/></V2QuickBtn>
      </div>
    </div>
  );
}
function V2RibbonTab({ active, onClick, children }) {
  const t = useTheme();
  const [h, setH] = React.useState(false);
  return (
    <div onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{
        padding: '0 14px', height: 34, display: 'flex', alignItems: 'center',
        fontSize: 12.5, fontWeight: active ? 500 : 400,
        color: active ? t.fg : (h ? t.fg : t.fgMuted),
        borderBottom: `2px solid ${active ? t.accent : 'transparent'}`,
        marginBottom: -1, cursor: 'default', letterSpacing: 0.4,
      }}>{children}</div>
  );
}
function V2QuickBtn({ children, active, dim, onClick }) {
  const t = useTheme();
  const [h, setH] = React.useState(false);
  return (
    <div onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{
        width: 28, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: dim ? t.fgFaint : (active ? t.accent : t.fgMuted),
        background: active ? t.accentSoft : (h ? t.hover : 'transparent'),
        borderRadius: 5, cursor: 'default',
      }}>{children}</div>
  );
}

// -----------------------------------------------------------------------------
// Contextual strip — the "smart ribbon body": morphs based on mode AND tab.
// If user is in Edit Text mode, the strip is text controls, regardless of tab.
// If mode is Browse, the strip reflects the current tab.
function V2Contextual({ state }) {
  const t = useTheme();
  return (
    <div style={{
      height: 44, display: 'flex', alignItems: 'center', gap: 8,
      padding: '0 16px',
      background: t.bg, borderBottom: `1px solid ${t.line}`,
    }}>
      {/* left: context label */}
      <V2ContextBadge state={state}/>
      <div style={{ width: 1, height: 20, background: t.line, margin: '0 6px' }}/>
      <V2ContextContent state={state}/>
    </div>
  );
}
function V2ContextBadge({ state }) {
  const t = useTheme();
  const label = modeLabel(state.mode, state.ribbonTab);
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 8,
      fontSize: 12, minWidth: 160,
    }}>
      <div style={{
        width: 26, height: 26, borderRadius: 6,
        background: t.accentSoft, color: t.accent,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>{modeIcon(state.mode, state.ribbonTab)}</div>
      <div>
        <div style={{ color: t.fg, fontWeight: 500, lineHeight: 1.1 }}>{label.title}</div>
        <div style={{ color: t.fgSubtle, fontSize: 10.5, lineHeight: 1.1, marginTop: 2 }}>{label.sub}</div>
      </div>
    </div>
  );
}
function modeLabel(mode, tab) {
  if (mode === 'edit_text')      return { title: '編輯文字', sub: '點選文字塊即可修改' };
  if (mode === 'add_text')       return { title: '新增文字框', sub: '拖曳繪製並輸入文字' };
  if (mode === 'rect')           return { title: '繪製矩形', sub: '拖曳繪製矩形' };
  if (mode === 'highlight')      return { title: '螢光筆', sub: '點選或拖曳反白文字' };
  if (mode === 'add_annotation') return { title: '新增註解', sub: '點擊位置插入便利貼' };
  if (mode === 'objects')        return { title: '操作物件', sub: '選取、搬移、調整大小' };
  // browse — show tab label
  return ({
    file:    { title: '檔案',  sub: '開啟、儲存、匯出' },
    common:  { title: '常用',  sub: '模式、檢視、歷史' },
    edit:    { title: '編輯',  sub: '文字、物件、註解、浮水印' },
    page:    { title: '頁面',  sub: '新增、刪除、旋轉、合併' },
    convert: { title: '轉換',  sub: 'OCR、匯出為其他格式' },
  })[tab] || { title: '瀏覽', sub: '選取與複製文字' };
}
function modeIcon(mode, tab) {
  if (mode === 'edit_text')      return <Icon.editText/>;
  if (mode === 'add_text')       return <Icon.addText/>;
  if (mode === 'rect')           return <Icon.rect/>;
  if (mode === 'highlight')      return <Icon.highlight/>;
  if (mode === 'add_annotation') return <Icon.annotate/>;
  if (mode === 'objects')        return <Icon.objects/>;
  return { file: <Icon.open/>, common: <Icon.hand/>, edit: <Icon.editText/>, page: <Icon.pages/>, convert: <Icon.ocr/> }[tab] || <Icon.hand/>;
}

function V2ContextContent({ state }) {
  const m = state.mode;
  if (m === 'browse') return <V2CtxTab state={state}/>;
  if (m === 'edit_text' || m === 'add_text') return <V2CtxText state={state}/>;
  if (m === 'rect')      return <V2CtxRect/>;
  if (m === 'highlight') return <V2CtxHighlight/>;
  if (m === 'add_annotation') return <V2CtxAnnotate/>;
  if (m === 'objects')   return <V2CtxObjects/>;
  return null;
}

function V2CtxTab({ state }) {
  // Browse — show quick actions from the current ribbon tab
  const items = {
    file: [
      { i: <Icon.open/>,     l: '開啟' },
      { i: <Icon.save/>,     l: '儲存' },
      { i: <Icon.saveAs/>,   l: '另存' },
      { i: <Icon.print/>,    l: '列印' },
      { i: <Icon.optimize/>, l: '最佳化' },
    ],
    common: [
      { i: <Icon.hand/>,       l: '瀏覽' },
      { i: <Icon.fullscreen/>, l: '全螢幕' },
      { i: <Icon.thumbs/>,     l: '縮圖' },
      { i: <Icon.search/>,     l: '搜尋' },
      { i: <Icon.snapshot/>,   l: '快照' },
    ],
    edit: [
      { i: <Icon.editText/>,  l: '編輯文字',  mode: 'edit_text' },
      { i: <Icon.addText/>,   l: '新增文字框', mode: 'add_text' },
      { i: <Icon.objects/>,   l: '操作物件',  mode: 'objects' },
      { i: <Icon.rect/>,      l: '矩形',      mode: 'rect' },
      { i: <Icon.highlight/>, l: '螢光筆',    mode: 'highlight' },
      { i: <Icon.annotate/>,  l: '新增註解',  mode: 'add_annotation' },
      { i: <Icon.watermark/>, l: '浮水印' },
    ],
    page: [
      { i: <Icon.insertBlank/>,   l: '空白頁' },
      { i: <Icon.insertFromFile/>, l: '從檔案' },
      { i: <Icon.deletePage/>,    l: '刪除頁' },
      { i: <Icon.rotatePage/>,    l: '旋轉頁' },
      { i: <Icon.exportPage/>,    l: '匯出頁' },
      { i: <Icon.merge/>,         l: '合併' },
    ],
    convert: [
      { i: <Icon.ocr/>, l: 'OCR 辨識' },
    ],
  }[state.ribbonTab] || [];
  return (
    <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
      {items.map((it, i) => (
        <V2Chip key={i} icon={it.i} onClick={() => it.mode && state.setMode(it.mode)}>{it.l}</V2Chip>
      ))}
    </div>
  );
}
function V2CtxText({ state }) {
  const t = useTheme();
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
      <V2Select value="cjk" label="字型" options={[
        { value: 'cjk', label: 'CJK Auto' },
        { value: 'helv', label: 'Sans (helv)' },
        { value: 'tiro', label: 'Serif (tiro)' },
        { value: 'cour', label: 'Mono (cour)' },
        { value: 'microsoft jhenghei', label: 'Microsoft JhengHei' },
        { value: 'pmingliu', label: 'PMingLiU' },
      ]} w={150}/>
      <V2Select value="12" label="字級" options={[8,10,12,14,16,18,20,22].map(n => ({ value: String(n), label: `${n} pt` }))} w={80}/>
      <V2ColorChip colors={['#111','#c23b3b','#2b5bd9','#1e7a4b']}/>
      <div style={{ width: 1, height: 20, background: t.line, margin: '0 4px' }}/>
      <V2Select value={state.targetMode} label="粒度"
        options={[{ value: 'run', label: '詞 / Run' }, { value: 'paragraph', label: '段落' }]}
        onChange={state.setTargetMode} w={110}/>
      <div style={{ flex: 1 }}/>
      <V2PrimaryBtn disabled={!state.editingBlockId} onClick={state.commitEdit}>套用</V2PrimaryBtn>
      <V2GhostBtn onClick={() => state.setMode('browse')}>完成</V2GhostBtn>
    </div>
  );
}
function V2CtxRect() {
  const t = useTheme();
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
      <V2ColorChip colors={['#2b5bd9', '#111', '#c23b3b', '#1e7a4b', '#f5a623']}/>
      <V2Select value="1" label="線寬" options={[{ value: '1', label: '1 pt' }, { value: '2', label: '2 pt' }, { value: '4', label: '4 pt' }]} w={80}/>
      <V2Toggle label="填色" checked/>
      <V2Toggle label="外框"/>
      <div style={{ flex: 1 }}/>
    </div>
  );
}
function V2CtxHighlight() {
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
      <V2ColorChip colors={['#fff176', '#81c784', '#ff8a80', '#90caf9', '#ce93d8']}/>
      <V2Select value="45" label="不透明度" options={[25,45,60,80].map(n => ({ value: String(n), label: `${n}%` }))} w={100}/>
    </div>
  );
}
function V2CtxAnnotate() {
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
      <V2Select value="note" label="類型" options={[{value:'note',label:'便利貼'},{value:'text',label:'文字註記'}]} w={120}/>
      <V2Select value="me" label="作者" options={[{value:'me',label:'我'},{value:'rev',label:'審核員'}]} w={100}/>
    </div>
  );
}
function V2CtxObjects() {
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
      <V2Chip icon={<Icon.objects/>}>選取</V2Chip>
      <V2Chip>群組</V2Chip>
      <V2Chip>解散</V2Chip>
      <V2Chip>對齊</V2Chip>
      <V2Chip>順序</V2Chip>
    </div>
  );
}

function V2Chip({ icon, children, onClick }) {
  const t = useTheme();
  const [h, setH] = React.useState(false);
  return (
    <div onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{
        display: 'flex', alignItems: 'center', gap: 6,
        height: 28, padding: '0 10px', borderRadius: 6, fontSize: 12,
        color: t.fg, background: h ? t.hover : 'transparent',
        cursor: 'default',
      }}>
      {icon && <span style={{ width: 20, height: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', color: t.fgMuted, flexShrink: 0 }}>{icon}</span>}
      {children}
    </div>
  );
}
function V2Select({ value, label, options, onChange, w = 100 }) {
  const t = useTheme();
  return (
    <label style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
      <span style={{ fontSize: 10.5, color: t.fgSubtle }}>{label}</span>
      <select value={value} onChange={(e) => onChange && onChange(e.target.value)}
        style={{
          width: w, height: 26, padding: '0 6px',
          fontSize: 12, fontFamily: 'inherit', color: t.fg,
          background: t.surface, border: `1px solid ${t.line}`, borderRadius: 5, outline: 'none',
        }}>{options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}</select>
    </label>
  );
}
function V2ColorChip({ colors }) {
  const t = useTheme();
  const [sel, setSel] = React.useState(0);
  return (
    <div style={{ display: 'flex', gap: 4, alignItems: 'center', padding: '2px 6px', background: t.surface, borderRadius: 6, border: `1px solid ${t.line}`, height: 26 }}>
      {colors.map((c, i) => (
        <div key={i} onClick={() => setSel(i)} style={{
          width: 16, height: 16, borderRadius: 4, background: c,
          border: sel === i ? `2px solid ${t.fg}` : `1px solid ${hexA('#000', 0.12)}`,
          cursor: 'default',
        }}/>
      ))}
    </div>
  );
}
function V2Toggle({ label, checked }) {
  const t = useTheme();
  const [on, setOn] = React.useState(!!checked);
  return (
    <div onClick={() => setOn(!on)}
      style={{
        display: 'flex', alignItems: 'center', gap: 6,
        height: 26, padding: '0 10px', borderRadius: 6,
        fontSize: 12,
        background: on ? t.accentSoft : 'transparent',
        color: on ? t.accent : t.fg, cursor: 'default',
      }}>
      <div style={{
        width: 12, height: 12, borderRadius: 3,
        border: `1.4px solid ${on ? t.accent : t.fgFaint}`,
        background: on ? t.accent : 'transparent',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>{on && <div style={{ color: '#fff', fontSize: 9, lineHeight: 1 }}>✓</div>}</div>
      {label}
    </div>
  );
}
function V2PrimaryBtn({ children, onClick, disabled }) {
  const t = useTheme();
  return (
    <div onClick={disabled ? undefined : onClick} style={{
      height: 28, padding: '0 14px', borderRadius: 6,
      display: 'flex', alignItems: 'center',
      background: disabled ? t.accentSoft : t.accent,
      color: disabled ? t.fgFaint : t.accentFg,
      fontSize: 12, fontWeight: 500, cursor: disabled ? 'not-allowed' : 'default',
    }}>{children}</div>
  );
}
function V2GhostBtn({ children, onClick }) {
  const t = useTheme();
  const [h, setH] = React.useState(false);
  return (
    <div onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{
        height: 28, padding: '0 12px', borderRadius: 6, display: 'flex', alignItems: 'center',
        border: `1px solid ${t.line}`, color: t.fg,
        background: h ? t.hover : 'transparent', fontSize: 12, cursor: 'default',
      }}>{children}</div>
  );
}

// -----------------------------------------------------------------------------
function V2DocTabs({ state }) {
  const t = useTheme();
  const tabs = [
    { label: '戶籍謄本申請書.pdf', dirty: true },
    { label: '房貸核貸資料.pdf', dirty: false },
    { label: '2024_ASHRAE_content.pdf', dirty: false },
  ];
  return (
    <div style={{
      display: 'flex', alignItems: 'stretch',
      background: t.bg, borderBottom: `1px solid ${t.line}`,
      padding: '0 0 0 56px', minHeight: 30,
    }}>
      {tabs.map((tab, i) => {
        const active = state.docTab === i;
        return (
          <div key={i} onClick={() => state.setDocTab(i)}
            style={{
              display: 'flex', alignItems: 'center', gap: 8,
              padding: '0 14px', minWidth: 170, maxWidth: 240,
              background: active ? t.surface : 'transparent',
              borderRight: `1px solid ${t.line}`,
              borderTop: active ? `2px solid ${t.accent}` : '2px solid transparent',
              fontSize: 12, color: active ? t.fg : t.fgMuted,
              cursor: 'default',
            }}>
            <div style={{
              width: 6, height: 6, borderRadius: '50%',
              background: tab.dirty ? t.accent : 'transparent',
              border: tab.dirty ? 'none' : `1px solid ${t.fgFaint}`,
            }}/>
            <span style={{ flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{tab.label}</span>
            <div style={{ opacity: active ? 1 : 0.5, color: t.fgSubtle }}><Icon.x/></div>
          </div>
        );
      })}
      <div style={{
        width: 32, display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: t.fgMuted,
      }}><Icon.plus/></div>
    </div>
  );
}

// -----------------------------------------------------------------------------
function V2Rail({ state }) {
  const t = useTheme();
  const tools = [
    { id: 'browse',         icon: <Icon.hand/>,      label: '瀏覽', key: 'H' },
    { id: 'edit_text',      icon: <Icon.editText/>,  label: '編輯文字', key: 'T' },
    { id: 'add_text',       icon: <Icon.addText/>,   label: '新增文字', key: 'A' },
    { id: 'highlight',      icon: <Icon.highlight/>, label: '螢光筆', key: 'L' },
    { id: 'rect',           icon: <Icon.rect/>,      label: '矩形',  key: 'R' },
    { id: 'add_annotation', icon: <Icon.annotate/>,  label: '註解',  key: 'N' },
    { id: 'objects',        icon: <Icon.objects/>,   label: '物件',  key: 'O' },
  ];
  const sidebars = [
    { id: 'thumbs',      icon: <Icon.thumbs/>,    label: '縮圖' },
    { id: 'search',      icon: <Icon.search/>,    label: '搜尋' },
    { id: 'annotations', icon: <Icon.comments/>,  label: '註解' },
    { id: 'watermarks',  icon: <Icon.watermark/>, label: '浮水印' },
    { id: 'bookmarks',   icon: <Icon.bookmark/>,  label: '書籤' },
  ];
  return (
    <div style={{
      width: 56, flexShrink: 0, background: t.surface,
      borderRight: `1px solid ${t.line}`,
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      padding: '8px 0',
    }}>
      {/* Modes */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {tools.map(tool => (
          <V2RailBtn key={tool.id} tool={tool} state={state}
            active={state.mode === tool.id} onClick={() => state.setMode(tool.id)}/>
        ))}
      </div>
      <div style={{ flex: 1 }}/>
      <div style={{ width: 24, height: 1, background: t.line, margin: '8px 0' }}/>
      {/* Sidebars */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {sidebars.map(sb => {
          const isActive = state.leftOpen && state.leftTab === sb.id;
          return (
            <V2SidebarBtn key={sb.id} sb={sb}
              active={isActive}
              onClick={() => {
                if (state.leftTab === sb.id && state.leftOpen) state.setLeftOpen(false);
                else { state.setLeftTab(sb.id); state.setLeftOpen(true); }
              }}/>
          );
        })}
      </div>
      <div style={{ width: 24, height: 1, background: t.line, margin: '8px 0' }}/>
      <V2RailBtn tool={{ icon: <Icon.settings/>, label: '設定', id: '_settings' }} state={state}/>
    </div>
  );
}
function V2RailBtn({ tool, active, onClick }) {
  const t = useTheme();
  const [h, setH] = React.useState(false);
  return (
    <div onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      title={`${tool.label}${tool.key ? ` (${tool.key})` : ''}`}
      style={{
        width: 40, height: 40, position: 'relative',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        borderRadius: 8,
        color: active ? t.accent : (h ? t.fg : t.fgMuted),
        background: active ? t.accentSoft : (h ? t.hover : 'transparent'),
        cursor: 'default',
      }}>
      {active && <div style={{
        position: 'absolute', left: -8, top: 10, bottom: 10, width: 2.5,
        background: t.accent, borderRadius: 2,
      }}/>}
      <div style={{ width: 26, height: 26, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{tool.icon}</div>
    </div>
  );
}
function V2SidebarBtn({ sb, active, onClick }) {
  return <V2RailBtn tool={sb} active={active} onClick={onClick}/>;
}

// -----------------------------------------------------------------------------
function V2LeftPanel({ state }) {
  const t = useTheme();
  const title = {
    thumbs: '縮圖', search: '搜尋', annotations: '註解', watermarks: '浮水印', bookmarks: '書籤',
  }[state.leftTab] || '';
  return (
    <div style={{
      width: 260, flexShrink: 0, background: t.surface,
      borderRight: `1px solid ${t.line}`,
      display: 'flex', flexDirection: 'column', overflow: 'hidden',
    }}>
      <div style={{
        height: 36, display: 'flex', alignItems: 'center',
        padding: '0 14px', borderBottom: `1px solid ${t.lineSoft}`,
      }}>
        <span style={{ fontSize: 11, color: t.fgSubtle, letterSpacing: 1.2, textTransform: 'uppercase' }}>{title}</span>
        <div style={{ flex: 1 }}/>
        <div onClick={() => state.setLeftOpen(false)}
          style={{ width: 22, height: 22, display: 'flex', alignItems: 'center', justifyContent: 'center', color: t.fgSubtle, cursor: 'default' }}>
          <Icon.chevronLeft/>
        </div>
      </div>
      <div style={{ flex: 1, overflow: 'auto' }}>
        {state.leftTab === 'thumbs' && (
          <div style={{ padding: 12 }}>
            <div onClick={() => state.setPage(1)} style={{
              width: '100%', aspectRatio: '595/842', overflow: 'hidden',
              background: t.paper, borderRadius: 3,
              border: state.page === 1 ? `2px solid ${t.accent}` : `1px solid ${t.line}`,
              boxShadow: t.shadowSm,
            }}>
              <div style={{ transform: 'scale(0.36)', transformOrigin: 'top left', width: 595, pointerEvents: 'none' }}>
                <FormPage filledValues={state.filledValues}/>
              </div>
            </div>
            <div style={{ textAlign: 'center', fontSize: 11, color: t.fgMuted, marginTop: 4 }}>1 · A4</div>
          </div>
        )}
        {state.leftTab === 'search' && (
          <div style={{ padding: 12 }}>
            <div style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '6px 10px', border: `1px solid ${t.line}`, borderRadius: 6,
              background: t.bg,
            }}>
              <Icon.search/>
              <input defaultValue="戶籍" placeholder="搜尋..." style={{
                flex: 1, border: 'none', outline: 'none', background: 'transparent',
                font: 'inherit', color: t.fg, fontSize: 12,
              }}/>
            </div>
            <div style={{ marginTop: 12, fontSize: 11, color: t.fgSubtle }}>在頁面 1 中找到 4 筆</div>
            {[
              { ctx: '戶籍謄本申請書', hit: '戶籍' },
              { ctx: '戶籍地址　Registered Address', hit: '戶籍' },
              { ctx: '戶籍謄本（現戶全戶）', hit: '戶籍' },
              { ctx: '除戶戶籍謄本', hit: '戶籍' },
            ].map((r, i) => (
              <div key={i} style={{
                padding: '8px 10px', borderRadius: 6, marginTop: 4,
                background: i === 0 ? t.accentSoft : 'transparent',
                fontSize: 12, color: t.fg, cursor: 'default',
              }}>{r.ctx.replace(r.hit, '')}
                <span style={{ background: '#ffe27a', padding: '0 2px', color: '#111' }}>{r.hit}</span>
              </div>
            ))}
          </div>
        )}
        {state.leftTab === 'annotations' && (
          <div style={{ padding: 8 }}>
            {state.annotations.map((a, i) => (
              <div key={i} style={{
                padding: '10px 12px', borderRadius: 6, marginBottom: 4,
                background: t.bg, borderLeft: `2px solid ${t.accent}`,
              }}>
                <div style={{ fontSize: 10.5, color: t.fgMuted, marginBottom: 3 }}>{a.author} · 第 1 頁</div>
                <div style={{ fontSize: 12 }}>{a.text}</div>
              </div>
            ))}
          </div>
        )}
        {state.leftTab === 'watermarks' && (
          <div style={{ padding: 12 }}>
            {state.watermark ? (
              <div style={{ padding: 10, border: `1px solid ${t.line}`, borderRadius: 6 }}>
                <div style={{ fontWeight: 500 }}>{state.watermark.text}</div>
                <div style={{ fontSize: 11, color: t.fgMuted, marginTop: 2 }}>
                  角度 {state.watermark.angle}° · 不透明度 {state.watermark.opacity}%
                </div>
                <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
                  <V2GhostBtn onClick={() => state.setWatermark(null)}>移除</V2GhostBtn>
                </div>
              </div>
            ) : (
              <>
                <div style={{ fontSize: 11.5, color: t.fgSubtle, marginBottom: 8 }}>尚未添加浮水印。</div>
                <V2PrimaryBtn onClick={() => state.setWatermark({ text: '機密 CONFIDENTIAL', opacity: 12, angle: -30 })}>添加浮水印</V2PrimaryBtn>
              </>
            )}
          </div>
        )}
        {state.leftTab === 'bookmarks' && (
          <div style={{ padding: 16, fontSize: 12, color: t.fgSubtle }}>此文件無書籤。</div>
        )}
      </div>
    </div>
  );
}

// -----------------------------------------------------------------------------
function V2Canvas({ state }) {
  const t = useTheme();
  const z = state.zoom / 100;
  return (
    <div style={{ flex: 1, minWidth: 0, background: t.sunken, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ flex: 1, overflow: 'auto' }}>
        <div style={{ padding: '32px 24px 48px', display: 'flex', justifyContent: 'center' }}>
          <div style={{ transform: `scale(${z})`, transformOrigin: 'top center', marginBottom: 842 * (z-1) }}>
            <FormPage
              mode={state.mode}
              selectedBlockId={state.selectedBlockId}
              hoveredBlockId={state.hoveredBlockId}
              editingBlockId={state.editingBlockId}
              editingValue={state.editingValue}
              onBlockHover={state.setHoveredBlockId}
              onBlockClick={state.onBlockClick}
              onEditChange={state.setEditingValue}
              onEditCommit={state.commitEdit}
              showBlockOutlines={state.showBlockOutlines}
              annotations={state.annotations}
              highlights={state.highlights}
              filledValues={state.filledValues}
              watermark={state.watermark}
            />
          </div>
        </div>
      </div>
      <V2CanvasChrome state={state}/>
    </div>
  );
}
function V2CanvasChrome({ state }) {
  const t = useTheme();
  return (
    <div style={{
      position: 'absolute', bottom: 40, left: '50%', transform: 'translateX(-50%)',
      display: 'flex', alignItems: 'center', gap: 6,
      padding: '6px 10px', background: t.elev,
      borderRadius: 10, border: `1px solid ${t.line}`,
      boxShadow: t.shadowMd, fontSize: 12,
    }}>
      <V2ZoomBtn onClick={() => state.setPage(Math.max(1, state.page - 1))}><Icon.chevronLeft/></V2ZoomBtn>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, minWidth: 46, textAlign: 'center' }}>{state.page} / 1</span>
      <V2ZoomBtn onClick={() => state.setPage(state.page + 1)}><Icon.chevronRight/></V2ZoomBtn>
      <div style={{ width: 1, height: 16, background: t.line, margin: '0 2px' }}/>
      <V2ZoomBtn onClick={() => state.setZoom(Math.max(25, state.zoom - 10))}><Icon.zoomOut/></V2ZoomBtn>
      <select value={state.zoom} onChange={(e) => state.setZoom(Number(e.target.value))}
        style={{
          border: 'none', background: 'transparent', color: t.fg,
          fontFamily: 'var(--font-mono)', fontSize: 11, outline: 'none', cursor: 'default',
        }}>
        {[50,75,90,100,125,150,175,200].map(z => <option key={z} value={z}>{z}%</option>)}
      </select>
      <V2ZoomBtn onClick={() => state.setZoom(Math.min(400, state.zoom + 10))}><Icon.zoomIn/></V2ZoomBtn>
      <div style={{ width: 1, height: 16, background: t.line, margin: '0 2px' }}/>
      <V2ZoomBtn onClick={() => state.setZoom(100)}><Icon.fitView/></V2ZoomBtn>
    </div>
  );
}
function V2ZoomBtn({ children, onClick }) {
  const t = useTheme();
  const [h, setH] = React.useState(false);
  return (
    <div onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{
        width: 24, height: 24, display: 'flex', alignItems: 'center', justifyContent: 'center',
        borderRadius: 4, color: t.fgMuted, background: h ? t.hover : 'transparent', cursor: 'default',
      }}>{children}</div>
  );
}

// -----------------------------------------------------------------------------
function V2Inspector({ state }) {
  const t = useTheme();
  return (
    <div style={{
      width: 288, flexShrink: 0, background: t.surface,
      borderLeft: `1px solid ${t.line}`,
      display: 'flex', flexDirection: 'column',
    }}>
      <div style={{
        height: 36, display: 'flex', alignItems: 'center',
        padding: '0 14px', borderBottom: `1px solid ${t.lineSoft}`,
      }}>
        <span style={{ fontSize: 11, color: t.fgSubtle, letterSpacing: 1.2, textTransform: 'uppercase' }}>檢查</span>
        <div style={{ flex: 1 }}/>
        <div onClick={() => state.setRightOpen(false)}
          style={{ width: 22, height: 22, display: 'flex', alignItems: 'center', justifyContent: 'center', color: t.fgSubtle, cursor: 'default' }}>
          <Icon.chevronRight/>
        </div>
      </div>
      <div style={{ flex: 1, overflow: 'auto' }}>
        <V2InspectorContent state={state}/>
      </div>
    </div>
  );
}

function V2InspectorContent({ state }) {
  const t = useTheme();
  return (
    <>
      <V2Section title="文件">
        <V2Row label="名稱">戶籍謄本申請書.pdf</V2Row>
        <V2Row label="頁數">1</V2Row>
        <V2Row label="尺寸">A4　595 × 842 pt</V2Row>
        <V2Row label="PDF 版本">1.7</V2Row>
        <V2Row label="加密">無</V2Row>
      </V2Section>

      {state.selectedBlockId && (
        <V2Section title="選取" accent>
          <V2Row label="類型">文字塊</V2Row>
          <V2Row label="ID"><code style={{ fontFamily: 'var(--font-mono)', fontSize: 11.5 }}>{state.selectedBlockId}</code></V2Row>
          <V2Row label="值">
            <div style={{ color: t.fg, fontSize: 12, wordBreak: 'break-all' }}>
              {state.filledValues[state.selectedBlockId] ?? '（原始內容）'}
            </div>
          </V2Row>
        </V2Section>
      )}

      <V2Section title="顯示">
        <div style={{ padding: '4px 0' }}>
          <V2Check label="顯示文字塊外框" checked={state.showBlockOutlines}/>
          <V2Check label="顯示註解" checked/>
          <V2Check label="顯示浮水印" checked={!!state.watermark}/>
          <V2Check label="顯示參考線"/>
        </div>
      </V2Section>

      <V2Section title="色彩設定檔">
        <V2Row label="輸出">
          <select style={{
            width: '100%', height: 26, padding: '0 6px', fontSize: 12,
            border: `1px solid ${t.line}`, borderRadius: 5, background: t.bg, color: t.fg,
            fontFamily: 'inherit', outline: 'none',
          }}>
            <option>sRGB</option><option>CMYK 預覽</option><option>灰階</option>
          </select>
        </V2Row>
      </V2Section>

      <V2Section title="歷史">
        {[
          { label: '修改欄位 用途', when: '2 分鐘前', me: true },
          { label: '新增註解', when: '5 分鐘前', me: false },
          { label: '添加浮水印', when: '上午 10:41', me: true },
        ].map((h, i) => (
          <div key={i} style={{
            display: 'flex', gap: 8, alignItems: 'flex-start',
            padding: '6px 0', borderTop: i > 0 ? `1px solid ${t.lineSoft}` : 'none',
          }}>
            <div style={{
              width: 6, height: 6, borderRadius: '50%',
              background: h.me ? t.accent : t.fgFaint, marginTop: 6,
            }}/>
            <div style={{ flex: 1, fontSize: 12, color: t.fg }}>
              {h.label}
              <div style={{ fontSize: 10.5, color: t.fgSubtle, marginTop: 1 }}>{h.when}</div>
            </div>
          </div>
        ))}
      </V2Section>
    </>
  );
}

function V2Section({ title, accent, children }) {
  const t = useTheme();
  return (
    <div style={{
      padding: '12px 16px', borderBottom: `1px solid ${t.lineSoft}`,
      background: accent ? t.accentSoft : 'transparent',
    }}>
      <div style={{ fontSize: 10.5, color: accent ? t.accent : t.fgSubtle, letterSpacing: 1, marginBottom: 8, fontWeight: accent ? 500 : 400 }}>{title}</div>
      {children}
    </div>
  );
}
function V2Row({ label, children }) {
  const t = useTheme();
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, padding: '3px 0' }}>
      <div style={{ width: 68, fontSize: 11, color: t.fgMuted, flexShrink: 0 }}>{label}</div>
      <div style={{ flex: 1, fontSize: 12, color: t.fg, minWidth: 0 }}>{children}</div>
    </div>
  );
}
function V2Check({ label, checked }) {
  const t = useTheme();
  const [c, setC] = React.useState(!!checked);
  return (
    <div onClick={() => setC(!c)} style={{
      display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0', cursor: 'default',
    }}>
      <div style={{
        width: 14, height: 14, borderRadius: 3,
        border: `1.4px solid ${c ? t.accent : t.fgFaint}`,
        background: c ? t.accent : 'transparent',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>{c && <div style={{ color: '#fff', fontSize: 9 }}>✓</div>}</div>
      <div style={{ fontSize: 12, color: t.fg }}>{label}</div>
    </div>
  );
}

// -----------------------------------------------------------------------------
function V2Status({ state }) {
  const t = useTheme();
  return (
    <div style={{
      height: 26, display: 'flex', alignItems: 'center',
      padding: '0 14px', borderTop: `1px solid ${t.line}`,
      background: t.surface, fontSize: 11, color: t.fgMuted, gap: 14,
    }}>
      <span style={{ color: t.accent, display: 'flex', alignItems: 'center', gap: 4 }}>
        <div style={{ width: 6, height: 6, borderRadius: '50%', background: t.accent }}/>
        已修改 · 自動儲存已停用
      </span>
      <span>頁面 {state.page}/1</span>
      <span>模式：{modeLabel(state.mode, state.ribbonTab).title}</span>
      <span>選取：{state.selectedBlockId || '—'}</span>
      <div style={{ flex: 1 }}/>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10.5, color: t.fgSubtle }}>
        UTF-8 · LF · {Object.keys(state.filledValues).length} 項變更
      </span>
    </div>
  );
}

window.V2RailContextual = V2RailContextual;
