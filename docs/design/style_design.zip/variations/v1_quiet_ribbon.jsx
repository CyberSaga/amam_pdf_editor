/* global React, useTheme, Icon, FormPage, useEditorState */
// =============================================================================
// V1 — Quiet Ribbon
// Faithful to the current PySide6 shell structure, but deeply cleaned up:
//   - Windows 11 title bar with acrylic feel
//   - Ribbon tabs: 檔案 / 常用 / 編輯 / 頁面 / 轉換
//   - Document tab bar (multi-tab)
//   - Left sidebar: 縮圖 / 搜尋 / 註解列表 / 浮水印列表
//   - Center canvas with page + rulers + modes
//   - Right property inspector (context-switching by mode)
//   - Status bar
// =============================================================================

function V1QuietRibbon({ state }) {
  const t = useTheme();
  const st = state;
  const d = t._density;

  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      background: t.bg, color: t.fg,
      fontFamily: 'var(--font-tc)', fontSize: 13,
      borderRadius: 8, overflow: 'hidden',
      boxShadow: t.shadowLg,
      border: `1px solid ${t.lineStrong}`,
    }}>
      <TitleBar/>
      <Ribbon state={st}/>
      <DocTabBar state={st}/>
      <div style={{ flex: 1, display: 'flex', minHeight: 0, background: t.bg }}>
        {st.leftOpen && <LeftSidebar state={st}/>}
        <Canvas state={st}/>
        {st.rightOpen && <RightInspector state={st}/>}
      </div>
      <StatusBar state={st}/>
    </div>
  );
}

// -----------------------------------------------------------------------------
function TitleBar() {
  const t = useTheme();
  return (
    <div style={{
      height: 34, display: 'flex', alignItems: 'center',
      background: t.surface,
      borderBottom: `1px solid ${t.lineSoft}`,
      paddingLeft: 10, paddingRight: 0,
      fontSize: 12, color: t.fgMuted,
      WebkitAppRegion: 'drag',
    }}>
      <div style={{
        width: 16, height: 16, borderRadius: 3,
        background: `linear-gradient(135deg, ${t.accent}, ${t.fg})`,
        marginRight: 8,
      }}/>
      <span style={{ fontWeight: 500, color: t.fg, letterSpacing: 0.2 }}>視覺化 PDF 編輯器</span>
      <span style={{ margin: '0 8px', color: t.fgFaint }}>·</span>
      <span>戶籍謄本申請書.pdf</span>
      <span style={{ flex: 1 }}/>
      <div style={{ display: 'flex', alignItems: 'center', gap: 0 }}>
        <WinBtn><Icon.winMin/></WinBtn>
        <WinBtn><Icon.winMax/></WinBtn>
        <WinBtn danger><Icon.winX/></WinBtn>
      </div>
    </div>
  );
}
function WinBtn({ children, danger }) {
  const t = useTheme();
  const [h, setH] = React.useState(false);
  return (
    <div
      onMouseEnter={() => setH(true)}
      onMouseLeave={() => setH(false)}
      style={{
        width: 46, height: 34, display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: danger && h ? '#fff' : t.fgMuted,
        background: h ? (danger ? '#e53935' : t.hover) : 'transparent',
        cursor: 'default',
      }}
    >{children}</div>
  );
}

// -----------------------------------------------------------------------------
function Ribbon({ state }) {
  const t = useTheme();
  const tabs = [
    { id: 'file',    label: '檔案' },
    { id: 'common',  label: '常用' },
    { id: 'edit',    label: '編輯' },
    { id: 'page',    label: '頁面' },
    { id: 'convert', label: '轉換' },
  ];
  return (
    <div style={{
      background: t.surface,
      borderBottom: `1px solid ${t.line}`,
    }}>
      {/* Tab strip */}
      <div style={{
        display: 'flex', alignItems: 'center',
        padding: '0 12px', height: 36,
        borderBottom: `1px solid ${t.lineSoft}`,
      }}>
        {tabs.map(tab => (
          <RibbonTab key={tab.id}
            active={state.ribbonTab === tab.id}
            onClick={() => state.setRibbonTab(tab.id)}>{tab.label}</RibbonTab>
        ))}
        <div style={{ flex: 1 }}/>
        <QuickBar state={state}/>
      </div>
      {/* Active ribbon content */}
      <div style={{
        height: 84, display: 'flex', alignItems: 'center',
        padding: '4px 12px', gap: 4, overflow: 'hidden',
      }}>
        {state.ribbonTab === 'file'    && <RibbonFile/>}
        {state.ribbonTab === 'common'  && <RibbonCommon state={state}/>}
        {state.ribbonTab === 'edit'    && <RibbonEdit state={state}/>}
        {state.ribbonTab === 'page'    && <RibbonPage/>}
        {state.ribbonTab === 'convert' && <RibbonConvert/>}
      </div>
    </div>
  );
}
function RibbonTab({ active, onClick, children }) {
  const t = useTheme();
  const [h, setH] = React.useState(false);
  return (
    <div onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{
        padding: '6px 14px', marginRight: 2,
        fontSize: 13, fontWeight: active ? 500 : 400,
        color: active ? t.fg : (h ? t.fg : t.fgMuted),
        borderBottom: `2px solid ${active ? t.accent : 'transparent'}`,
        cursor: 'default',
        letterSpacing: 0.4,
      }}>{children}</div>
  );
}

function QuickBar({ state }) {
  const t = useTheme();
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
      <QuickBtn tip="復原 (Ctrl+Z)"><Icon.undo/></QuickBtn>
      <QuickBtn tip="重做 (Ctrl+Y)" dim><Icon.redo/></QuickBtn>
      <Sep/>
      <QuickBtn tip="快速指令 (Ctrl+K)"><Icon.cmd/></QuickBtn>
      <QuickBtn tip="左側邊欄 (Ctrl+Alt+L)"
        active={state.leftOpen}
        onClick={() => state.setLeftOpen(!state.leftOpen)}><Icon.sidebar/></QuickBtn>
      <QuickBtn tip="右側邊欄 (Ctrl+Alt+R)"
        active={state.rightOpen}
        onClick={() => state.setRightOpen(!state.rightOpen)}><Icon.sidebarR/></QuickBtn>
      <QuickBtn tip="全螢幕 (F5)"><Icon.fullscreen/></QuickBtn>
    </div>
  );
}
function QuickBtn({ children, tip, active, dim, onClick }) {
  const t = useTheme();
  const [h, setH] = React.useState(false);
  return (
    <div title={tip} onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{
        width: 28, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center',
        borderRadius: 6, cursor: 'default',
        color: dim ? t.fgFaint : (active ? t.accent : t.fgMuted),
        background: active ? t.accentSoft : (h ? t.hover : 'transparent'),
      }}>{children}</div>
  );
}
function Sep() { const t = useTheme(); return <div style={{ width: 1, height: 18, background: t.line, margin: '0 4px' }}/>; }

// -----------------------------------------------------------------------------
// Ribbon content per tab
function Group({ label, children }) {
  const t = useTheme();
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center',
      padding: '0 10px', borderRight: `1px solid ${t.lineSoft}`,
      height: 76, justifyContent: 'space-between',
    }}>
      <div style={{ display: 'flex', gap: 2, alignItems: 'flex-start' }}>{children}</div>
      <div style={{ fontSize: 10, color: t.fgSubtle, letterSpacing: 1, paddingBottom: 2 }}>{label}</div>
    </div>
  );
}
function RibbonBtn({ icon, label, shortcut, active, big, onClick, tone }) {
  const t = useTheme();
  const [h, setH] = React.useState(false);
  const color = tone === 'accent' ? t.accent : (active ? t.accent : t.fg);
  const bg = active ? t.accentSoft : (h ? t.hover : 'transparent');
  if (big) {
    return (
      <div onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)} title={shortcut}
        style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-start',
          width: 60, height: 64, padding: '4px 4px 5px', borderRadius: 8, cursor: 'default',
          color, background: bg, gap: 4,
        }}>
        <div style={{ width: 36, height: 36, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{icon}</div>
        <div style={{ fontSize: 10.5, lineHeight: 1.1, textAlign: 'center', whiteSpace: 'nowrap' }}>{label}</div>
      </div>
    );
  }
  return (
    <div onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)} title={shortcut}
      style={{
        display: 'flex', alignItems: 'center', gap: 6,
        padding: '6px 10px', height: 28, borderRadius: 6,
        color, background: bg, cursor: 'default', fontSize: 12,
      }}>
      <span style={{ width: 16, height: 16, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{icon}</span>
      {label}
    </div>
  );
}

function RibbonFile() {
  return (
    <>
      <Group label="檔案">
        <RibbonBtn big icon={<Icon.open/>}     label="開啟"           shortcut="Ctrl+O"/>
        <RibbonBtn big icon={<Icon.save/>}     label="儲存"           shortcut="Ctrl+S"/>
        <RibbonBtn big icon={<Icon.saveAs/>}   label="另存新檔"       shortcut="Ctrl+Shift+S"/>
      </Group>
      <Group label="輸出">
        <RibbonBtn big icon={<Icon.print/>}    label="列印"           shortcut="Ctrl+P"/>
        <RibbonBtn big icon={<Icon.optimize/>} label="最佳化副本"/>
      </Group>
    </>
  );
}
function RibbonCommon({ state }) {
  return (
    <>
      <Group label="模式">
        <RibbonBtn big icon={<Icon.hand/>}    label="瀏覽"     active={state.mode==='browse'}  onClick={() => state.setMode('browse')}/>
        <RibbonBtn big icon={<Icon.objects/>} label="操作物件" active={state.mode==='objects'} onClick={() => state.setMode('objects')} shortcut="F3"/>
      </Group>
      <Group label="歷史">
        <RibbonBtn big icon={<Icon.undo/>} label="復原" shortcut="Ctrl+Z"/>
        <RibbonBtn big icon={<Icon.redo/>} label="重做" shortcut="Ctrl+Y"/>
      </Group>
      <Group label="檢視">
        <RibbonBtn big icon={<Icon.fullscreen/>} label="全螢幕" shortcut="F5"/>
        <RibbonBtn big icon={<Icon.thumbs/>}     label="縮圖" active={state.leftTab==='thumbs' && state.leftOpen} onClick={() => { state.setLeftTab('thumbs'); state.setLeftOpen(true); }}/>
        <RibbonBtn big icon={<Icon.search/>}     label="搜尋" active={state.leftTab==='search' && state.leftOpen} onClick={() => { state.setLeftTab('search'); state.setLeftOpen(true); }}/>
        <RibbonBtn big icon={<Icon.snapshot/>}   label="快照"/>
      </Group>
    </>
  );
}
function RibbonEdit({ state }) {
  return (
    <>
      <Group label="文字">
        <RibbonBtn big icon={<Icon.editText/>} label="編輯文字"    active={state.mode==='edit_text'} onClick={() => state.setMode('edit_text')} shortcut="F2"/>
        <RibbonBtn big icon={<Icon.addText/>}  label="新增文字框" active={state.mode==='add_text'}  onClick={() => state.setMode('add_text')}/>
      </Group>
      <Group label="物件">
        <RibbonBtn big icon={<Icon.objects/>}  label="操作物件" active={state.mode==='objects'} onClick={() => state.setMode('objects')} shortcut="F3"/>
      </Group>
      <Group label="標記">
        <RibbonBtn big icon={<Icon.rect/>}      label="矩形"   active={state.mode==='rect'}      onClick={() => state.setMode('rect')}/>
        <RibbonBtn big icon={<Icon.highlight/>} label="螢光筆" active={state.mode==='highlight'} onClick={() => state.setMode('highlight')}/>
      </Group>
      <Group label="圖片">
        <RibbonBtn big icon={<Icon.insertImage/>} label="插入圖片"/>
        <RibbonBtn big icon={<Icon.pasteImage/>}  label="貼上圖片"/>
      </Group>
      <Group label="註解">
        <RibbonBtn big icon={<Icon.annotate/>} label="新增註解" active={state.mode==='add_annotation'} onClick={() => state.setMode('add_annotation')}/>
        <RibbonBtn big icon={<Icon.comments/>} label="註解列表" onClick={() => { state.setLeftTab('annotations'); state.setLeftOpen(true); }}/>
        <RibbonBtn big icon={<Icon.eye/>}      label="顯示/隱藏"/>
      </Group>
      <Group label="浮水印">
        <RibbonBtn big icon={<Icon.watermark/>} label="添加浮水印" onClick={() => state.setWatermark({ text: '機密 CONFIDENTIAL', opacity: 12, angle: -30 })}/>
        <RibbonBtn big icon={<Icon.layers/>}    label="浮水印列表" onClick={() => { state.setLeftTab('watermarks'); state.setLeftOpen(true); }}/>
      </Group>
    </>
  );
}
function RibbonPage() {
  return (
    <>
      <Group label="頁面">
        <RibbonBtn big icon={<Icon.deletePage/>} label="刪除頁"/>
        <RibbonBtn big icon={<Icon.rotatePage/>} label="旋轉頁"/>
        <RibbonBtn big icon={<Icon.exportPage/>} label="匯出頁"/>
      </Group>
      <Group label="插入">
        <RibbonBtn big icon={<Icon.insertBlank/>}    label="空白頁"/>
        <RibbonBtn big icon={<Icon.insertFromFile/>} label="從檔案"/>
      </Group>
      <Group label="合併">
        <RibbonBtn big icon={<Icon.merge/>} label="合併 PDF"/>
      </Group>
    </>
  );
}
function RibbonConvert() {
  return (
    <Group label="辨識">
      <RibbonBtn big icon={<Icon.ocr/>} label="OCR 文字辨識"/>
    </Group>
  );
}

// -----------------------------------------------------------------------------
function DocTabBar({ state }) {
  const t = useTheme();
  const tabs = [
    { label: '戶籍謄本申請書.pdf', dirty: true },
    { label: '房貸核貸資料.pdf', dirty: false },
    { label: '2024_ASHRAE_content.pdf', dirty: false },
  ];
  return (
    <div style={{
      display: 'flex', alignItems: 'flex-end',
      background: t.bg, borderBottom: `1px solid ${t.line}`,
      padding: '4px 8px 0', gap: 2, minHeight: 32,
    }}>
      {tabs.map((tab, i) => (
        <DocTab key={i} tab={tab} active={state.docTab === i} onClick={() => state.setDocTab(i)}/>
      ))}
      <div style={{
        width: 24, height: 24, display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: t.fgMuted, cursor: 'default', marginLeft: 4, marginBottom: 4,
      }}><Icon.plus/></div>
    </div>
  );
}
function DocTab({ tab, active, onClick }) {
  const t = useTheme();
  const [h, setH] = React.useState(false);
  return (
    <div onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{
        display: 'flex', alignItems: 'center', gap: 6,
        padding: '6px 10px 8px', minWidth: 140, maxWidth: 220,
        background: active ? t.surface : (h ? t.hover : 'transparent'),
        borderTopLeftRadius: 8, borderTopRightRadius: 8,
        borderTop: active ? `1px solid ${t.line}` : '1px solid transparent',
        borderLeft: active ? `1px solid ${t.line}` : '1px solid transparent',
        borderRight: active ? `1px solid ${t.line}` : '1px solid transparent',
        borderBottom: active ? `1px solid ${t.surface}` : 'none',
        marginBottom: -1,
        fontSize: 12, color: active ? t.fg : t.fgMuted, cursor: 'default',
      }}>
      <div style={{
        width: 6, height: 6, borderRadius: '50%',
        background: tab.dirty ? t.accent : 'transparent',
        border: tab.dirty ? 'none' : `1px solid ${t.fgFaint}`,
      }}/>
      <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', flex: 1 }}>{tab.label}</span>
      <div style={{ width: 14, height: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', color: t.fgSubtle, opacity: active ? 1 : 0.5 }}><Icon.x/></div>
    </div>
  );
}

// -----------------------------------------------------------------------------
function LeftSidebar({ state }) {
  const t = useTheme();
  const tabs = [
    { id: 'thumbs',      label: '縮圖',       icon: <Icon.thumbs/> },
    { id: 'search',      label: '搜尋',       icon: <Icon.search/> },
    { id: 'annotations', label: '註解列表',   icon: <Icon.comments/> },
    { id: 'watermarks',  label: '浮水印列表', icon: <Icon.watermark/> },
    { id: 'bookmarks',   label: '書籤',       icon: <Icon.bookmark/> },
  ];
  return (
    <div style={{
      width: 264, flexShrink: 0, display: 'flex', flexDirection: 'column',
      background: t.surface, borderRight: `1px solid ${t.line}`,
    }}>
      {/* Tab rail */}
      <div style={{ display: 'flex', borderBottom: `1px solid ${t.line}`, padding: '0 4px', gap: 0 }}>
        {tabs.map(tab => (
          <div key={tab.id} onClick={() => state.setLeftTab(tab.id)}
            title={tab.label}
            style={{
              flex: 1, height: 36, display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: state.leftTab === tab.id ? t.accent : t.fgMuted,
              borderBottom: `2px solid ${state.leftTab === tab.id ? t.accent : 'transparent'}`,
              cursor: 'default',
            }}>{tab.icon}</div>
        ))}
      </div>
      {/* Panel body */}
      <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        {state.leftTab === 'thumbs'      && <ThumbsPanel state={state}/>}
        {state.leftTab === 'search'      && <SearchPanel/>}
        {state.leftTab === 'annotations' && <AnnotationsPanel state={state}/>}
        {state.leftTab === 'watermarks'  && <WatermarksPanel state={state}/>}
        {state.leftTab === 'bookmarks'   && <BookmarksPanel/>}
      </div>
    </div>
  );
}

function PanelHeader({ title, actions }) {
  const t = useTheme();
  return (
    <div style={{
      display: 'flex', alignItems: 'center',
      padding: '8px 12px',
      fontSize: 11, letterSpacing: 1, textTransform: 'none',
      color: t.fgSubtle, fontWeight: 500,
    }}>
      <span style={{ flex: 1 }}>{title}</span>
      {actions}
    </div>
  );
}

function ThumbsPanel({ state }) {
  const t = useTheme();
  return (
    <>
      <PanelHeader title="縮圖 · 共 1 頁"/>
      <div style={{ flex: 1, overflow: 'auto', padding: '4px 12px 12px' }}>
        {[1].map(n => (
          <div key={n} onClick={() => state.setPage(n)}
            style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center',
              marginBottom: 10,
            }}>
            <div style={{
              width: '100%', aspectRatio: '595/842',
              background: t.paper,
              border: state.page === n ? `2px solid ${t.accent}` : `1px solid ${t.line}`,
              borderRadius: 3, boxShadow: t.shadowSm,
              position: 'relative', overflow: 'hidden',
            }}>
              <div style={{ transform: 'scale(0.37)', transformOrigin: 'top left', width: 595, pointerEvents: 'none' }}>
                <FormPage pageNumber={n} filledValues={state.filledValues}/>
              </div>
            </div>
            <div style={{ marginTop: 6, fontSize: 11, color: state.page === n ? t.fg : t.fgMuted }}>{n}</div>
          </div>
        ))}
      </div>
    </>
  );
}

function SearchPanel() {
  const t = useTheme();
  return (
    <>
      <PanelHeader title="搜尋"/>
      <div style={{ padding: '0 12px' }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 6,
          padding: '6px 10px', border: `1px solid ${t.line}`, borderRadius: 6,
          background: t.bg,
        }}>
          <Icon.search/>
          <input placeholder="輸入文字搜尋..." style={{
            flex: 1, border: 'none', outline: 'none', background: 'transparent',
            font: 'inherit', color: t.fg, fontSize: 12,
          }}/>
          <kbd style={{
            fontSize: 10, color: t.fgSubtle, border: `1px solid ${t.line}`,
            borderRadius: 3, padding: '1px 4px', background: t.surface,
          }}>Esc</kbd>
        </div>
      </div>
      <div style={{ padding: '12px', fontSize: 11.5, color: t.fgSubtle }}>
        輸入關鍵字以搜尋文件內容。
      </div>
    </>
  );
}

function AnnotationsPanel({ state }) {
  const t = useTheme();
  return (
    <>
      <PanelHeader title={`註解 · ${state.annotations.length}`}/>
      <div style={{ flex: 1, overflow: 'auto', padding: '0 8px' }}>
        {state.annotations.map((a, i) => (
          <div key={i} style={{
            padding: '8px 10px', borderRadius: 6,
            marginBottom: 4,
            background: t.bg,
            borderLeft: `2px solid ${t.accent}`,
          }}>
            <div style={{ fontSize: 10.5, color: t.fgMuted, marginBottom: 2 }}>
              {a.author}　·　第 1 頁
            </div>
            <div style={{ fontSize: 12, color: t.fg }}>{a.text}</div>
          </div>
        ))}
      </div>
    </>
  );
}

function WatermarksPanel({ state }) {
  const t = useTheme();
  return (
    <>
      <PanelHeader title={`浮水印 · ${state.watermark ? 1 : 0}`}/>
      <div style={{ padding: 12 }}>
        {state.watermark ? (
          <div style={{
            padding: 10, border: `1px solid ${t.line}`, borderRadius: 6, background: t.bg,
          }}>
            <div style={{ fontSize: 12, fontWeight: 500, marginBottom: 4 }}>{state.watermark.text}</div>
            <div style={{ fontSize: 11, color: t.fgMuted }}>角度 {state.watermark.angle}° · 不透明度 {state.watermark.opacity}%</div>
            <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
              <SmallBtn>編輯</SmallBtn>
              <SmallBtn danger onClick={() => state.setWatermark(null)}>移除</SmallBtn>
            </div>
          </div>
        ) : (
          <div style={{ fontSize: 11.5, color: t.fgSubtle }}>尚未添加浮水印。</div>
        )}
      </div>
    </>
  );
}

function BookmarksPanel() {
  const t = useTheme();
  return <div style={{ padding: 16, fontSize: 12, color: t.fgSubtle }}>此文件無書籤。</div>;
}

function SmallBtn({ children, danger, onClick }) {
  const t = useTheme();
  const [h, setH] = React.useState(false);
  return (
    <div onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{
        padding: '3px 10px', borderRadius: 4, fontSize: 11,
        border: `1px solid ${danger ? t.dangerSoft : t.line}`,
        color: danger ? t.danger : t.fg,
        background: h ? (danger ? t.dangerSoft : t.hover) : 'transparent',
        cursor: 'default',
      }}>{children}</div>
  );
}

// -----------------------------------------------------------------------------
function Canvas({ state }) {
  const t = useTheme();
  const z = state.zoom / 100;
  return (
    <div style={{
      flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column',
      background: t.sunken,
    }}>
      <ModeStrip state={state}/>
      <div style={{ flex: 1, overflow: 'auto', position: 'relative' }}>
        <div style={{
          padding: '32px 24px 40px',
          display: 'flex', justifyContent: 'center',
        }}>
          <div style={{
            transform: `scale(${z})`, transformOrigin: 'top center',
            marginBottom: 842 * (z - 1),
          }}>
            <FormPage
              mode={state.mode}
              selectedBlockId={state.selectedBlockId}
              hoveredBlockId={state.hoveredBlockId}
              editingBlockId={state.editingBlockId}
              editingValue={state.editingValue}
              onBlockHover={state.setHoveredBlockId}
              onBlockClick={state.onBlockClick}
              onEditChange={state.setEditingValue}
              onEditCommit={state.commitEdit}
              showBlockOutlines={state.showBlockOutlines}
              annotations={state.annotations}
              highlights={state.highlights}
              filledValues={state.filledValues}
              watermark={state.watermark}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function ModeStrip({ state }) {
  const t = useTheme();
  const label = {
    browse: '瀏覽模式 · 可選取與複製文字',
    edit_text: '編輯文字 · 點擊文字塊即可編輯',
    add_text: '新增文字框 · 點擊空白處插入',
    rect: '矩形 · 拖曳繪製矩形',
    highlight: '螢光筆 · 點擊文字反白',
    add_annotation: '新增註解 · 點擊位置新增',
    objects: '操作物件 · 點擊選取，Shift 多選',
  }[state.mode] || '';
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 8,
      padding: '6px 16px',
      background: t.bg,
      borderBottom: `1px solid ${t.lineSoft}`,
      fontSize: 11.5, color: t.fgMuted, minHeight: 30,
    }}>
      <div style={{
        width: 6, height: 6, borderRadius: '50%',
        background: state.mode === 'browse' ? t.fgFaint : t.accent,
      }}/>
      <span style={{ color: t.fg, fontWeight: 500 }}>{label.split(' · ')[0]}</span>
      <span style={{ color: t.fgSubtle }}>{label.split(' · ')[1]}</span>
      <span style={{ flex: 1 }}/>
      <span style={{ fontSize: 11, color: t.fgSubtle }}>文字選取粒度</span>
      <select value={state.targetMode}
        onChange={(e) => state.setTargetMode(e.target.value)}
        style={{
          fontSize: 11, padding: '2px 6px',
          border: `1px solid ${t.line}`, borderRadius: 4,
          background: t.surface, color: t.fg, fontFamily: 'inherit',
        }}>
        <option value="run">詞 / Run</option>
        <option value="paragraph">段落</option>
      </select>
    </div>
  );
}

// -----------------------------------------------------------------------------
function RightInspector({ state }) {
  const t = useTheme();
  return (
    <div style={{
      width: 288, flexShrink: 0, display: 'flex', flexDirection: 'column',
      background: t.surface, borderLeft: `1px solid ${t.line}`,
      overflow: 'hidden',
    }}>
      <div style={{
        padding: '10px 14px',
        borderBottom: `1px solid ${t.line}`,
        display: 'flex', alignItems: 'center',
      }}>
        <span style={{ fontSize: 13, fontWeight: 500, color: t.fg, letterSpacing: 0.4 }}>屬性</span>
        <span style={{ flex: 1 }}/>
        <span style={{ fontSize: 10.5, color: t.fgSubtle }}>
          {state.mode === 'browse' ? '頁面資訊' : contextLabel(state.mode)}
        </span>
      </div>
      <div style={{ flex: 1, overflow: 'auto' }}>
        <ColorProfileCard/>
        {state.mode === 'browse'         && <PageInfoCard state={state}/>}
        {state.mode === 'rect'           && <RectCard/>}
        {state.mode === 'highlight'      && <HighlightCard/>}
        {(state.mode === 'edit_text' || state.mode === 'add_text') && <TextCard state={state}/>}
        {state.mode === 'add_annotation' && <AnnotationCard/>}
        {state.mode === 'objects'        && <ObjectsCard state={state}/>}
      </div>
    </div>
  );
}
function contextLabel(m) {
  return ({
    edit_text: '文字設定', add_text: '新增文字框設定', rect: '矩形設定',
    highlight: '螢光筆設定', add_annotation: '註解設定', objects: '物件屬性',
  })[m] || '';
}

function InspectorGroup({ title, children }) {
  const t = useTheme();
  return (
    <div style={{ padding: '12px 14px', borderBottom: `1px solid ${t.lineSoft}` }}>
      <div style={{ fontSize: 10.5, color: t.fgSubtle, letterSpacing: 1, marginBottom: 8 }}>{title}</div>
      {children}
    </div>
  );
}
function Field({ label, children }) {
  const t = useTheme();
  return (
    <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8, gap: 8 }}>
      <div style={{ width: 76, fontSize: 11.5, color: t.fgMuted }}>{label}</div>
      <div style={{ flex: 1 }}>{children}</div>
    </div>
  );
}
function Input({ value, mono }) {
  const t = useTheme();
  return (
    <input defaultValue={value} style={{
      width: '100%', padding: '4px 8px', fontSize: 12,
      fontFamily: mono ? 'var(--font-mono)' : 'inherit',
      border: `1px solid ${t.line}`, borderRadius: 4,
      background: t.bg, color: t.fg, outline: 'none',
    }}/>
  );
}
function Select({ value, options, onChange }) {
  const t = useTheme();
  return (
    <select value={value} onChange={(e) => onChange && onChange(e.target.value)} style={{
      width: '100%', padding: '4px 8px', fontSize: 12,
      border: `1px solid ${t.line}`, borderRadius: 4,
      background: t.bg, color: t.fg, fontFamily: 'inherit', outline: 'none',
    }}>{options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}</select>
  );
}
function Swatch({ color }) {
  return <div style={{ width: 16, height: 16, borderRadius: 3, background: color, border: '1px solid rgba(0,0,0,0.1)' }}/>;
}

function ColorProfileCard() {
  const t = useTheme();
  return (
    <InspectorGroup title="色彩設定檔">
      <Select value="srgb" options={[
        { value: 'srgb', label: 'sRGB' },
        { value: 'gray', label: '灰階' },
        { value: 'cmyk', label: 'CMYK 預覽' },
      ]}/>
    </InspectorGroup>
  );
}

function PageInfoCard({ state }) {
  const t = useTheme();
  return (
    <>
      <InspectorGroup title="頁面資訊">
        <Field label="尺寸">A4　595 × 842 pt</Field>
        <Field label="旋轉">0°</Field>
        <Field label="頁碼">{state.page} / 1</Field>
        <Field label="目前模式">{state.mode}</Field>
      </InspectorGroup>
      <InspectorGroup title="文件">
        <Field label="建立者">內政部戶政司</Field>
        <Field label="加密">無</Field>
        <Field label="PDF 版本">1.7</Field>
        <Field label="大小">248 KB</Field>
      </InspectorGroup>
      {state.selectedBlockId && (
        <InspectorGroup title="選取片段">
          <Field label="欄位 ID"><code style={{ fontFamily: 'var(--font-mono)', fontSize: 11.5 }}>{state.selectedBlockId}</code></Field>
          <Field label="內容"><div style={{ fontSize: 12, color: t.fg, wordBreak: 'break-all' }}>
            {state.filledValues[state.selectedBlockId] ?? '（原始內容）'}
          </div></Field>
        </InspectorGroup>
      )}
    </>
  );
}

function RectCard() {
  const t = useTheme();
  return (
    <>
      <InspectorGroup title="矩形設定">
        <Field label="顏色">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Swatch color={t.accent}/>
            <input defaultValue="#2B5BD9" style={{ flex: 1, padding: '4px 8px', fontSize: 11.5, fontFamily: 'var(--font-mono)', border: `1px solid ${t.line}`, borderRadius: 4, background: t.bg, color: t.fg, outline: 'none' }}/>
          </div>
        </Field>
        <Field label="透明度"><Slider value={100}/></Field>
        <Field label="填色">
          <div style={{ display: 'flex', gap: 4 }}>
            <SegBtn active>填色</SegBtn><SegBtn>外框</SegBtn>
          </div>
        </Field>
      </InspectorGroup>
      <InspectorGroup title="動作">
        <div style={{ display: 'flex', gap: 8 }}>
          <ActionBtn primary>套用</ActionBtn>
          <ActionBtn>取消</ActionBtn>
        </div>
      </InspectorGroup>
    </>
  );
}

function HighlightCard() {
  const t = useTheme();
  const colors = ['#fff176', '#81c784', '#ff8a80', '#90caf9', '#ce93d8'];
  return (
    <InspectorGroup title="螢光筆顏色">
      <div style={{ display: 'flex', gap: 6 }}>
        {colors.map((c, i) => (
          <div key={i} style={{
            width: 28, height: 28, borderRadius: 6,
            background: c, border: i === 0 ? `2px solid ${t.accent}` : `1px solid ${t.line}`,
            cursor: 'default',
          }}/>
        ))}
      </div>
      <div style={{ marginTop: 12 }}>
        <Field label="不透明度"><Slider value={45}/></Field>
      </div>
    </InspectorGroup>
  );
}

function TextCard({ state }) {
  const t = useTheme();
  return (
    <>
      <InspectorGroup title="文字設定">
        <Field label="字型">
          <Select value="cjk" options={[
            { value: 'helv', label: 'Sans (helv)' },
            { value: 'tiro', label: 'Serif (tiro)' },
            { value: 'cour', label: 'Mono (cour)' },
            { value: 'cjk',  label: 'CJK Auto (cjk)' },
            { value: 'microsoft jhenghei', label: 'Microsoft JhengHei' },
            { value: 'pmingliu', label: 'PMingLiU' },
            { value: 'dfkai-sb', label: 'DFKai-SB' },
          ]}/>
        </Field>
        <Field label="字級">
          <div style={{ display: 'flex', gap: 6 }}>
            <Select value="12" options={[8,10,12,14,16,18,20,22,24,28].map(n => ({ value: String(n), label: `${n} pt` }))}/>
          </div>
        </Field>
        <Field label="顏色">
          <div style={{ display: 'flex', gap: 4 }}>
            {['#111','#c23b3b','#2b5bd9','#1e7a4b'].map((c,i) => (
              <div key={i} style={{ width: 20, height: 20, borderRadius: 4, background: c, border: i===0 ? `2px solid ${t.accent}`:`1px solid ${t.line}` }}/>
            ))}
          </div>
        </Field>
      </InspectorGroup>
      <InspectorGroup title="選取">
        <Field label="粒度">
          <Select value={state.targetMode} onChange={state.setTargetMode} options={[
            { value: 'run', label: '詞 / Run（精準）' },
            { value: 'paragraph', label: '段落（整段）' },
          ]}/>
        </Field>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11.5, color: t.fgMuted }}>
          <input type="checkbox" defaultChecked/> 垂直文字擴展時左移
        </div>
      </InspectorGroup>
      <InspectorGroup title="動作">
        <div style={{ display: 'flex', gap: 8 }}>
          <ActionBtn primary disabled={!state.editingBlockId} onClick={state.commitEdit}>套用</ActionBtn>
          <ActionBtn disabled={!state.editingBlockId} onClick={() => { state.setEditingValue(''); state.commitEdit(); }}>取消</ActionBtn>
        </div>
        <div style={{ marginTop: 8, fontSize: 10.5, color: t.fgSubtle, lineHeight: 1.5 }}>
          {state.editingBlockId
            ? <>正在編輯 <code style={{ fontFamily: 'var(--font-mono)' }}>{state.editingBlockId}</code>，按 Enter 套用，Esc 取消。</>
            : '點擊文件中的任一文字塊以開始編輯。'}
        </div>
      </InspectorGroup>
    </>
  );
}

function AnnotationCard() {
  return (
    <InspectorGroup title="註解設定">
      <Field label="類型">
        <Select value="note" options={[
          { value: 'note', label: '便利貼' },
          { value: 'text', label: '文字註記' },
        ]}/>
      </Field>
      <Field label="作者"><Input value="我"/></Field>
    </InspectorGroup>
  );
}

function ObjectsCard({ state }) {
  const t = useTheme();
  return (
    <>
      <InspectorGroup title="選取物件">
        {state.selectedBlockId
          ? <div style={{ fontSize: 12, color: t.fg }}>
              <div style={{ marginBottom: 4 }}>類型　<span style={{ color: t.fgMuted }}>文字方塊</span></div>
              <div>識別　<code style={{ fontFamily: 'var(--font-mono)', fontSize: 11.5 }}>{state.selectedBlockId}</code></div>
            </div>
          : <div style={{ fontSize: 11.5, color: t.fgSubtle }}>點擊物件以選取，Shift+Click 可多選（同頁）。</div>}
      </InspectorGroup>
      <InspectorGroup title="變形">
        <Field label="位置">
          <div style={{ display: 'flex', gap: 4 }}>
            <Input value="134.0" mono/><Input value="216.5" mono/>
          </div>
        </Field>
        <Field label="尺寸">
          <div style={{ display: 'flex', gap: 4 }}>
            <Input value="220.0" mono/><Input value="22.0" mono/>
          </div>
        </Field>
        <Field label="旋轉"><Input value="0°" mono/></Field>
      </InspectorGroup>
    </>
  );
}

function ActionBtn({ children, primary, disabled, onClick }) {
  const t = useTheme();
  const [h, setH] = React.useState(false);
  return (
    <div onClick={disabled ? undefined : onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{
        padding: '5px 12px', fontSize: 12, borderRadius: 5,
        background: primary ? (disabled ? t.accentSoft : t.accent) : (h ? t.hover : t.surface),
        color: primary ? (disabled ? t.fgFaint : t.accentFg) : (disabled ? t.fgFaint : t.fg),
        border: primary ? 'none' : `1px solid ${t.line}`,
        opacity: disabled ? 0.7 : 1,
        cursor: disabled ? 'not-allowed' : 'default',
      }}>{children}</div>
  );
}
function SegBtn({ active, children }) {
  const t = useTheme();
  return (
    <div style={{
      flex: 1, textAlign: 'center', padding: '4px 0', fontSize: 11.5,
      borderRadius: 4, border: `1px solid ${active ? t.accent : t.line}`,
      color: active ? t.accent : t.fgMuted,
      background: active ? t.accentSoft : 'transparent',
      cursor: 'default',
    }}>{children}</div>
  );
}
function Slider({ value = 50 }) {
  const t = useTheme();
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <div style={{ flex: 1, height: 4, background: t.line, borderRadius: 2, position: 'relative' }}>
        <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${value}%`, background: t.accent, borderRadius: 2 }}/>
        <div style={{ position: 'absolute', left: `calc(${value}% - 6px)`, top: -4, width: 12, height: 12, borderRadius: '50%', background: t.surface, border: `2px solid ${t.accent}`, boxShadow: t.shadowSm }}/>
      </div>
      <span style={{ fontSize: 11, color: t.fgMuted, minWidth: 28, textAlign: 'right' }}>{value}%</span>
    </div>
  );
}

// -----------------------------------------------------------------------------
function StatusBar({ state }) {
  const t = useTheme();
  const bits = [];
  if (Object.keys(state.filledValues).length > 0) bits.push('已修改');
  bits.push('連續捲動');
  bits.push(`頁面 ${state.page}/1`);
  bits.push(`縮放 ${state.zoom}%`);
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 0,
      height: 26, padding: '0 12px',
      borderTop: `1px solid ${t.line}`,
      background: t.surface,
      fontSize: 11, color: t.fgMuted,
    }}>
      {bits.map((b, i) => (
        <React.Fragment key={i}>
          <span>{b}</span>
          {i < bits.length - 1 && <span style={{ margin: '0 10px', color: t.fgFaint }}>·</span>}
        </React.Fragment>
      ))}
      <div style={{ flex: 1 }}/>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <Icon.zoomOut/>
        <div style={{
          fontFamily: 'var(--font-mono)', fontSize: 11, minWidth: 40,
          textAlign: 'center', padding: '1px 6px',
          background: t.bg, border: `1px solid ${t.line}`, borderRadius: 3,
        }}>{state.zoom}%</div>
        <Icon.zoomIn/>
        <span style={{ margin: '0 8px', color: t.fgFaint }}>·</span>
        <span>Ctrl+K 快速指令</span>
      </div>
    </div>
  );
}

window.V1QuietRibbon = V1QuietRibbon;
