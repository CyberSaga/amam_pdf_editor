/* global React, ReactDOM, DesignCanvas, DCSection, DCArtboard, DCPostIt,
          ThemeProvider, V1QuietRibbon, V2RailContextual, useEditorState, Icon,
          useLocalState, PALETTES */

// =============================================================================
// App — six pastel lavender/purple palette variations of the V1 shell,
// plus the V2 shell for reference. Tweaks panel for theme/density/accent.
// =============================================================================

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "light",
  "density": "comfortable",
  "showV2": true
}/*EDITMODE-END*/;

// Six soft pastel lavender/purple palettes — ordered cool → warm → neutral.
const PALETTE_ORDER = [
  'lavender_mist',
  'lilac_cream',
  'periwinkle_sky',
  'mauve_dust',
  'wisteria_bloom',
  'heather_fog',
];

// Six reading-comfort variants, all evolved from Lavender Mist.
// Each tunes a different comfort dimension — see notes on each palette in tokens.jsx.
const COMFORT_ORDER = [
  'paper_white',
  'ivory_mist',
  'morning_frost',
  'muted_stone',
  'dawn_veil',
  'deep_silk',
];

const COMFORT_NOTES = {
  paper_white:   '近白面板＋更深文字色，最直接的對比提升',
  ivory_mist:    '紙張改為米色——降低 LCD 反光，最適合長時間閱讀',
  morning_frost: '偏冷的乾淨表面＋最深文字色——適合編輯型工作',
  muted_stone:   '去飽和的灰紫——降低周邊視覺的色彩噪訊',
  dawn_veil:     '淡化分隔線、提升文字對比——分頁與面板更不打擾',
  deep_silk:     '加深底色保留層次＋強對比文字——專注模式',
};

// Round 3 — Pale Pastel + White Panels.
// All combine Morning-Frost-level near-white surfaces with paler, more pastel chrome.
const PALE_ORDER = [
  'pale_iris',
  'whisper_lilac',
  'cloud_lavender',
  'spring_haze',
  'porcelain',
  'fresh_air',
];

const PALE_NOTES = {
  pale_iris:      '專注模式 · 偏冷的淡虹紫，chrome 較晨霜略淡且更通透',
  whisper_lilac:  '微帶粉色的紫丁——溫暖但不甜膩',
  cloud_lavender: '純薰衣草色相，最輕盈的版本',
  spring_haze:    '長春花方向的藍紫——chrome 帶一點清爽感',
  porcelain:      '低視覺負擔模式 · 幾乎中性的瓷紫，色彩干擾最低',
  fresh_air:      '面板純白＋淺淡 chrome——對比最強的清爽方案',
};

// Two of the pale variants are designated as official modes.
const PALE_MODES = {
  pale_iris:  { tag: '專注模式',     en: 'Concentration' },
  porcelain:  { tag: '低視覺負擔',   en: 'Low Visual Burden' },
};

// Round 4 — Dark mode variants, same lavender DNA as the pale palettes.
// Mirrors the light system 1:1 — two official modes, three extended hues.
const DARK_ORDER = [
  'midnight_iris',
  'ink_silk',
  'velvet_dusk',
  'twilight_mist',
  'ink_porcelain',
];

const DARK_NOTES = {
  midnight_iris: '專注模式 · 冷調深紫、層次最清晰——對應淡虹',
  ink_silk:      '深沉編輯 · 高對比、純紫黑底色，OLED 螢幕最佳',
  velvet_dusk:   '溫暖夜讀 · 略帶粉調的暖紫——適合長時間夜間閱讀',
  twilight_mist: '低對比柔光 · 抬升整體亮度、減弱分隔線——平靜模式',
  ink_porcelain: '低視覺負擔 · 幾乎中性的炭灰，色彩干擾最低——對應瓷紫',
};

const DARK_MODES = {
  midnight_iris: { tag: '專注模式',   en: 'Concentration' },
  ink_porcelain: { tag: '低視覺負擔', en: 'Low Visual Burden' },
};

// Round 5 — Lupine.
// Translated from the Morphous Lupine system (魯冰花). 5 light-mode variants.
const LUPINE_ORDER = [
  'alpine_snow',
  'meadow_lupine',
  'petal_lupine',
  'silver_alpine',
  'deep_iris_lupine',
];

const LUPINE_NOTES = {
  alpine_snow:      '正典版 · 冷調近白面板＋飽和靛紫＋葉綠焦點環',
  meadow_lupine:    '草甸版 · 面板帶綠色暖意——alpine sky over a meadow',
  petal_lupine:     '花瓣版 · 底色採薰衣草霧、accent 用較淡的 Petal Indigo',
  silver_alpine:    '銀光版 · 中性銀灰 chrome，accent 維持 Lupine 靛紫——最 OS 質感',
  deep_iris_lupine: '深虹版 · 飽和度最高的薰衣草底＋全飽和 Lupine 靛紫',
};

function App() {
  const [tweakMode, setTweakMode] = React.useState(false);
  const [tweaks, setTweaks] = useLocalState('pdf_ed:tweaks', TWEAK_DEFAULTS);

  // Edit-mode plumbing
  React.useEffect(() => {
    const onMsg = (e) => {
      const d = e.data || {};
      if (d.type === '__activate_edit_mode') setTweakMode(true);
      if (d.type === '__deactivate_edit_mode') setTweakMode(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);
  const patchTweaks = (p) => {
    const next = { ...tweaks, ...p };
    setTweaks(next);
    window.parent.postMessage({ type: '__edit_mode_set_keys', edits: p }, '*');
  };

  // One editor state per artboard so they're independently interactive.
  const states = PALETTE_ORDER.map(id => useEditorState('v1_' + id));
  const comfortStates = COMFORT_ORDER.map(id => useEditorState('c_' + id));
  const paleStates = PALE_ORDER.map(id => useEditorState('pale_' + id));
  const darkStates = DARK_ORDER.map(id => useEditorState('dark_' + id));
  const lupineStates = LUPINE_ORDER.map(id => useEditorState('lup_' + id));
  const v2State = useEditorState('v2');

  return (
    <DesignCanvas>
      {/* Round 5 — Lupine — Morphous Lupine design system translated to PDF editor */}
      <DCSection
        id="lupine"
        title="魯冰花 · Lupine 配色版本 · 5 variations"
        subtitle="將 Morphous Lupine（高山魯冰花）設計系統移植到 PDF 編輯器——深靛紫主色＋葉綠焦點環＋alpine 冷白面板。從正典版逐步調整到與既有薰衣草系列銜接。"
      >
        {LUPINE_ORDER.map((paletteId, i) => {
          const p = PALETTES[paletteId];
          const num = String(i + 1).padStart(2, '0');
          return (
            <DCArtboard
              key={paletteId}
              id={'lup_' + paletteId}
              label={`${num} · ${p.name}　${p.en}　— ${LUPINE_NOTES[paletteId]}`}
              width={1360}
              height={860}
            >
              <ThemeProvider
                theme="light"
                density={tweaks.density}
                palette={paletteId}
              >
                <div
                  data-screen-label={`Lupine ${num} ${p.en}`}
                  style={{ width: '100%', height: '100%', position: 'relative' }}
                >
                  <V1QuietRibbon state={lupineStates[i]} />
                  <PaletteChip
                    palette={p}
                    badge={i === 0 ? '正典' : '魯冰花'}
                    primary={i === 0}
                  />
                </div>
              </ThemeProvider>
            </DCArtboard>
          );
        })}

        <DCPostIt top={-24} left={1376} rotate={3} width={230}>
          Lupine 的視覺簽名是 <b>飽和靛紫</b>（#4338CA）＋ <b>葉綠焦點環</b>（#16A34A）——
          比我們既有的薰衣草更深、更有「產品感」。
        </DCPostIt>
        <DCPostIt top={300} left={1376} rotate={-2} width={230}>
          01 正典最忠於原系統；
          02 草甸面板帶綠；
          03 花瓣保留薰衣草感最強——與既有系列銜接最自然；
          04 銀光最中性、OS 質感；
          05 深虹色彩最強。
        </DCPostIt>
        <DCPostIt top={620} left={1376} rotate={2} width={230}>
          所有版本沿用 V1 殼層結構與互動——你可以開啟側欄、切換工具列分頁、選擇頁面，與既有版本一模一樣。
        </DCPostIt>
      </DCSection>

      {/* Round 4 — Dark mode variants */}
      <DCSection
        id="dark"
        title="深色模式 · 5 versions　Dark Mode"
        subtitle="延續淡彩版本的薰衣草 DNA——兩個官方模式：01 深夜虹 = 專注模式 Concentration　·　05 墨瓷 = 低視覺負擔 Low Visual Burden"
      >
        {DARK_ORDER.map((paletteId, i) => {
          const p = PALETTES[paletteId];
          const num = String(i + 1).padStart(2, '0');
          const mode = DARK_MODES[paletteId];
          return (
            <DCArtboard
              key={paletteId}
              id={'dark_' + paletteId}
              label={
                mode
                  ? `${num} · ${p.name}　${p.en}　【${mode.tag} · ${mode.en}】`
                  : `${num} · ${p.name}　${p.en}　— ${DARK_NOTES[paletteId]}`
              }
              width={1360}
              height={860}
            >
              <ThemeProvider
                theme="dark"
                density={tweaks.density}
                palette={paletteId}
              >
                <div
                  data-screen-label={`Dark ${num} ${p.en}${mode ? ' · ' + mode.en : ''}`}
                  style={{ width: '100%', height: '100%', position: 'relative' }}
                >
                  <V1QuietRibbon state={darkStates[i]} />
                  <PaletteChip palette={p} badge={mode ? mode.tag : '夜色'} primary={!!mode} dark/>
                  {mode && <ModeBanner mode={mode}/>}
                </div>
              </ThemeProvider>
            </DCArtboard>
          );
        })}

        <DCPostIt top={-24} left={1376} rotate={3} width={220}>
          深色模式延續同樣的色系結構：bg 為中等深度、surface 抬升、sunken 最深、紙張保留象牙白以降低 LCD 眩光。
        </DCPostIt>
        <DCPostIt top={520} left={1376} rotate={-2} width={220}>
          01 深夜虹 對應淡虹（專注）；05 墨瓷 對應瓷紫（低負擔）。中間三款為延伸夜間色相。
        </DCPostIt>
      </DCSection>

      {/* Round 3 — pale pastel chrome + white panels */}
      <DCSection
        id="pale"
        title="淡彩面板版本 · 白面板 + 更淡的紫色 chrome"
        subtitle="兩個官方模式：01 淡虹 = 專注模式 Concentration　·　05 瓷紫 = 低視覺負擔 Low Visual Burden"
      >
        {PALE_ORDER.map((paletteId, i) => {
          const p = PALETTES[paletteId];
          const num = String(i + 1).padStart(2, '0');
          const mode = PALE_MODES[paletteId];
          return (
            <DCArtboard
              key={paletteId}
              id={'pale_' + paletteId}
              label={
                mode
                  ? `${num} · ${p.name}　${p.en}　【${mode.tag} · ${mode.en}】`
                  : `${num} · ${p.name}　${p.en}　— ${PALE_NOTES[paletteId]}`
              }
              width={1360}
              height={860}
            >
              <ThemeProvider
                theme={tweaks.theme}
                density={tweaks.density}
                palette={paletteId}
              >
                <div
                  data-screen-label={`Pale ${num} ${p.en}${mode ? ' · ' + mode.en : ''}`}
                  style={{ width: '100%', height: '100%', position: 'relative' }}
                >
                  <V1QuietRibbon state={paleStates[i]} />
                  <PaletteChip palette={p} badge={mode ? mode.tag : '淡彩'} primary={!!mode}/>
                  {mode && <ModeBanner mode={mode}/>}
                </div>
              </ThemeProvider>
            </DCArtboard>
          );
        })}

        <DCPostIt top={-24} left={1376} rotate={3} width={220}>
          01 淡虹 = 專注模式：冷調、最清晰；
          05 瓷紫 = 低視覺負擔：色彩近灰、不打擾。
          其餘四款為延伸色相選項。
        </DCPostIt>
        <DCPostIt top={520} left={1376} rotate={-2} width={220}>
          所有面板（標題列、色帶、側欄、屬性面板）皆採用近白色——
          僅底色與 canvas well 為淺淡的紫色 pastel。
        </DCPostIt>
      </DCSection>

      {/* Round 2 — reading-comfort variants */}
      <DCSection
        id="comfort"
        title="參考 · 讀寫舒適度版本"
        subtitle="同樣的薰衣草 DNA，六種不同的舒適度策略——對比、紙張、飽和度、層次分離"
      >
        {COMFORT_ORDER.map((paletteId, i) => {
          const p = PALETTES[paletteId];
          const num = String(i + 1).padStart(2, '0');
          return (
            <DCArtboard
              key={paletteId}
              id={'c_' + paletteId}
              label={`${num} · ${p.name}　${p.en}　— ${COMFORT_NOTES[paletteId]}`}
              width={1360}
              height={860}
            >
              <ThemeProvider
                theme={tweaks.theme}
                density={tweaks.density}
                palette={paletteId}
              >
                <div
                  data-screen-label={`Comfort ${num} ${p.en}`}
                  style={{ width: '100%', height: '100%', position: 'relative' }}
                >
                  <V1QuietRibbon state={comfortStates[i]} />
                  <PaletteChip palette={p} comfort/>
                </div>
              </ThemeProvider>
            </DCArtboard>
          );
        })}

        <DCPostIt top={-24} left={1376} rotate={3} width={220}>
          全部以 薰衣草霧 為基底——只調對比、線色、紙色，不改變 UI 結構。
        </DCPostIt>
        <DCPostIt top={520} left={1376} rotate={-2} width={220}>
          長時間閱讀建議：02 米霧 或 04 鈍紫石。
          編輯密集建議：03 晨霜 或 06 深紫絹。
        </DCPostIt>
      </DCSection>

      {/* Original palette exploration kept below for reference */}
      <DCSection
        id="palettes"
        title="參考 · 初版六色票"
        subtitle="冷 → 暖 → 中性：薰衣草霧、丁香奶霜、長春花、紫絨塵、紫藤盛開、石楠迷霧"
      >
        {PALETTE_ORDER.map((paletteId, i) => {
          const p = PALETTES[paletteId];
          const num = String(i + 1).padStart(2, '0');
          return (
            <DCArtboard
              key={paletteId}
              id={'p_' + paletteId}
              label={`${num} · ${p.name}　${p.en}`}
              width={1360}
              height={860}
            >
              <ThemeProvider
                theme={tweaks.theme}
                density={tweaks.density}
                palette={paletteId}
              >
                <div
                  data-screen-label={`${num} ${p.en}`}
                  style={{ width: '100%', height: '100%', position: 'relative' }}
                >
                  <V1QuietRibbon state={states[i]} />
                  <PaletteChip palette={p} />
                </div>
              </ThemeProvider>
            </DCArtboard>
          );
        })}

        <DCPostIt top={-24} left={1376} rotate={3} width={210}>
          六種配色皆延續原本的視窗結構、色帶分頁、左右側欄與檢視器——
          只調整底色、面板、線框與強調色。
        </DCPostIt>
        <DCPostIt top={500} left={1376} rotate={-2} width={210}>
          冷 → 暖 → 中性順序排列：薰衣草霧、丁香奶霜、長春花、紫絨塵、紫藤盛開、石楠迷霧。
        </DCPostIt>
      </DCSection>

      {tweaks.showV2 && (
        <DCSection
          id="v2_reference"
          title="參考 · V2 Rail + Contextual"
          subtitle="保留原本的工具列＋情境列方案，使用第一組「薰衣草霧」配色"
        >
          <DCArtboard id="v2" label="V2 · Rail + Contextual" width={1360} height={860}>
            <ThemeProvider
              theme={tweaks.theme}
              density={tweaks.density}
              palette="lavender_mist"
            >
              <div
                data-screen-label="V2 Rail Contextual"
                style={{ width: '100%', height: '100%' }}
              >
                <V2RailContextual state={v2State} />
              </div>
            </ThemeProvider>
          </DCArtboard>
        </DCSection>
      )}

      {tweakMode && <TweaksPanel tweaks={tweaks} patchTweaks={patchTweaks} />}
    </DesignCanvas>
  );
}

// -----------------------------------------------------------------------------
// Small overlay badge that names the palette and shows its three key swatches,
// sitting in the corner of each artboard.
function PaletteChip({ palette, comfort, badge, primary, dark }) {
  const tag = badge || (comfort ? '讀寫舒適' : null);
  // Light variant on light palettes; lifted-dark glass on dark palettes.
  const chipBg = dark ? 'rgba(28,24,40,0.78)' : 'rgba(255,255,255,0.78)';
  const swatchRing = dark ? '#1c1828' : '#fff';
  const swatchShadow = dark ? '0 0 0 0.5px rgba(255,255,255,0.10)' : '0 0 0 0.5px rgba(40,28,72,0.15)';
  const textColor = dark ? '#ecebf5' : '#2a223b';
  const subColor  = dark ? '#a89ec4' : '#5a5172';
  const borderColor = primary
    ? (dark ? 'rgba(196,170,232,0.55)' : 'rgba(122,92,192,0.55)')
    : (dark ? 'rgba(255,255,255,0.10)' : 'rgba(40,28,72,0.10)');
  const chipShadow = primary
    ? (dark
        ? '0 4px 18px rgba(0,0,0,0.45), 0 0 0 3px rgba(196,170,232,0.16)'
        : '0 4px 18px rgba(122,92,192,0.30), 0 0 0 3px rgba(122,92,192,0.10)')
    : (dark
        ? '0 2px 10px rgba(0,0,0,0.40)'
        : '0 2px 10px rgba(40,28,72,0.10)');
  const tagBg = primary
    ? (dark ? '#b395ec' : '#5b3fa8')
    : (dark ? '#a48ee0' : '#7a5cc0');
  const tagFg = dark ? '#15121f' : '#fff';
  return (
    <div style={{
      position: 'absolute', top: 12, right: 12, zIndex: 5,
      display: 'flex', alignItems: 'center', gap: 8,
      padding: '6px 10px 6px 6px',
      background: chipBg,
      backdropFilter: 'blur(8px)',
      WebkitBackdropFilter: 'blur(8px)',
      borderRadius: 999,
      border: `1.5px solid ${borderColor}`,
      boxShadow: chipShadow,
      fontFamily: 'var(--font-tc)', fontSize: 11,
      color: textColor,
      pointerEvents: 'none',
    }}>
      <div style={{ display: 'flex', gap: 0 }}>
        {palette.swatches.map((c, i) => (
          <div key={i} style={{
            width: 14, height: 14, borderRadius: '50%',
            background: c,
            border: `1.5px solid ${swatchRing}`,
            marginLeft: i === 0 ? 0 : -5,
            boxShadow: swatchShadow,
          }}/>
        ))}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.15 }}>
        <span style={{ fontWeight: 600, letterSpacing: 0.3 }}>{palette.name}</span>
        <span style={{ fontSize: 9.5, color: subColor, letterSpacing: 0.6 }}>
          {palette.en.toUpperCase()}
        </span>
      </div>
      {tag && (
        <div style={{
          fontSize: 9, fontWeight: 700, letterSpacing: 0.8,
          padding: '2px 6px', borderRadius: 4,
          background: tagBg, color: tagFg,
          marginLeft: 2,
        }}>{tag}</div>
      )}
    </div>
  );
}

// -----------------------------------------------------------------------------
// A subtle ribbon shown on the two designated mode artboards, marking
// "Concentration" and "Low Visual Burden" as the recommended modes.
function ModeBanner({ mode }) {
  return (
    <div style={{
      position: 'absolute', top: 12, left: 12, zIndex: 5,
      display: 'flex', alignItems: 'center', gap: 8,
      padding: '6px 10px',
      background: 'linear-gradient(135deg, #7a5cc0, #5b3fa8)',
      color: '#fff',
      borderRadius: 6,
      fontFamily: 'var(--font-tc)', fontSize: 11,
      boxShadow: '0 3px 12px rgba(91,63,168,0.30)',
      pointerEvents: 'none',
      letterSpacing: 0.4,
    }}>
      <div style={{
        width: 6, height: 6, borderRadius: '50%', background: '#fff',
        boxShadow: '0 0 0 3px rgba(255,255,255,0.25)',
      }}/>
      <span style={{ fontWeight: 700 }}>{mode.tag}</span>
      <span style={{ opacity: 0.8, fontSize: 10, letterSpacing: 0.6 }}>
        {mode.en.toUpperCase()}
      </span>
    </div>
  );
}

// -----------------------------------------------------------------------------
function TweaksPanel({ tweaks, patchTweaks }) {
  return (
    <div style={{
      position: 'fixed', right: 20, bottom: 20, width: 280, zIndex: 200,
      background: '#15181d', color: '#e8eaed', borderRadius: 10,
      boxShadow: '0 20px 60px rgba(0,0,0,0.5)', border: '1px solid #2a2e36',
      padding: 14, fontFamily: 'var(--font-tc)', fontSize: 12.5,
    }}>
      <div style={{
        fontSize: 11, letterSpacing: 1.2, textTransform: 'uppercase',
        color: '#8a8f9c', marginBottom: 10,
      }}>Tweaks</div>
      <TwRow label="主題">
        <TwSeg
          value={tweaks.theme}
          onChange={(v) => patchTweaks({ theme: v })}
          options={[{ v: 'light', l: '淺色' }, { v: 'dark', l: '深色' }]}
        />
      </TwRow>
      <TwRow label="密度">
        <TwSeg
          value={tweaks.density}
          onChange={(v) => patchTweaks({ density: v })}
          options={[{ v: 'comfortable', l: '舒適' }, { v: 'compact', l: '緊湊' }]}
        />
      </TwRow>
      <TwRow label="V2 區">
        <TwSeg
          value={tweaks.showV2 ? 'on' : 'off'}
          onChange={(v) => patchTweaks({ showV2: v === 'on' })}
          options={[{ v: 'on', l: '顯示' }, { v: 'off', l: '隱藏' }]}
        />
      </TwRow>
      <div style={{
        marginTop: 10, paddingTop: 10, borderTop: '1px solid #2a2e36',
        fontSize: 10.5, color: '#7c818d', lineHeight: 1.55,
      }}>
        色票本身為設計探索方案，固定六種——切換主題到「深色」會以單一深色版本覆蓋全部畫板。
      </div>
    </div>
  );
}

function TwRow({ label, children }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', marginBottom: 10, gap: 10 }}>
      <div style={{ width: 56, color: '#8a8f9c', fontSize: 11 }}>{label}</div>
      <div style={{ flex: 1 }}>{children}</div>
    </div>
  );
}

function TwSeg({ value, onChange, options }) {
  return (
    <div style={{
      display: 'flex', gap: 2, padding: 2,
      background: '#0b0d10', borderRadius: 6,
    }}>
      {options.map(o => (
        <div key={o.v} onClick={() => onChange(o.v)} style={{
          flex: 1, textAlign: 'center', padding: '4px 0', borderRadius: 4,
          fontSize: 11.5, cursor: 'default',
          background: value === o.v ? '#2a2e36' : 'transparent',
          color: value === o.v ? '#fff' : '#a0a6b0',
        }}>{o.l}</div>
      ))}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
